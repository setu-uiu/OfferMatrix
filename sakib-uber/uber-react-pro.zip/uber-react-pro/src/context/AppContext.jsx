import React, { createContext, useContext, useState, useEffect } from 'react';

const AppContext = createContext();

// Default Constants
const DEFAULT_PRICING = {
  storeDiscount: 10,       // 10%
  couponCode: 'KIREI10',   // KIREI10
  bkashCashback: 150,      // ৳ 150
  shippingCost: 0,         // ৳ 0 Surge
  salePrice: 2050,         // ৳ 2,050
};

const DEFAULT_COUPONS = [
  { code: 'KIREI10', discount: 10, maxCap: 150, status: 'Active', title: '10% Platform Discount' },
  { code: 'UBER50', discount: 50, maxCap: 180, status: 'Active', title: '50% First Rides Offer' },
  { code: 'AIRPORT100', discount: 25, maxCap: 100, status: 'Active', title: '৳ 100 Airport Saver' },
  { code: 'COMFORT20', discount: 20, maxCap: 120, status: 'Active', title: '20% Luxury Comfort' },
  { code: 'MOTO30', discount: 30, maxCap: 50, status: 'Active', title: '৳ 30 Off Uber Moto' },
];

export const VEHICLE_RATES = {
  uberx: { name: 'UberX', base: 120, perKm: 24, capacity: '4 seats', eta: '3 mins away', icon: '🚗', desc: 'Affordable, everyday reliable rides' },
  comfort: { name: 'Uber Comfort', base: 160, perKm: 32, capacity: '4 seats', eta: '5 mins away', icon: '🚙', desc: 'Newer cars with extra legroom & top drivers' },
  uberxl: { name: 'UberXL', base: 220, perKm: 42, capacity: '6 seats', eta: '6 mins away', icon: '🚐', desc: 'Spacious SUVs for groups up to 6' },
  black: { name: 'Uber Black', base: 350, perKm: 55, capacity: '4 seats', eta: '8 mins away', icon: '🚘', desc: 'Premium luxury rides with professional chauffeurs' },
  moto: { name: 'Uber Moto', base: 50, perKm: 10, capacity: '1 seat', eta: '2 mins away', icon: '🏍️', desc: 'Fast, affordable motorbike trips through traffic' },
};

export const AppProvider = ({ children }) => {
  // Theme state
  const [theme, setTheme] = useState(() => localStorage.getItem('uber_react_theme') || 'light');

  // Screen State: 'auth', 'customer', 'driver', 'admin'
  const [currentScreen, setCurrentScreen] = useState('auth');
  const [selectedAuthRole, setSelectedAuthRole] = useState('customer');

  // Admin Pricing with localStorage persistence
  const [adminPricing, setAdminPricing] = useState(() => {
    try {
      const saved = localStorage.getItem('uber_react_pricing');
      return saved ? { ...DEFAULT_PRICING, ...JSON.parse(saved) } : DEFAULT_PRICING;
    } catch {
      return DEFAULT_PRICING;
    }
  });

  // Coupons List with localStorage persistence and synced first coupon
  const [coupons, setCoupons] = useState(() => {
    try {
      const saved = localStorage.getItem('uber_react_coupons');
      const list = saved ? JSON.parse(saved) : DEFAULT_COUPONS;
      if (list.length > 0) {
        list[0].code = adminPricing.couponCode;
        list[0].discount = adminPricing.storeDiscount;
        list[0].maxCap = adminPricing.bkashCashback;
      }
      return list;
    } catch {
      return DEFAULT_COUPONS;
    }
  });

  // Customer Profile & Wallet
  const [customer, setCustomer] = useState(() => ({
    name: 'Nazmus Sakib',
    phone: '+880 1711-234567',
    walletBalance: parseFloat(localStorage.getItem('uber_react_wallet')) || 550.00,
    appliedCoupon: null,
  }));

  // Driver Profile & Earnings
  const [driver, setDriver] = useState(() => ({
    name: 'Mohammad Rafiq',
    car: 'Silver Toyota Corolla (DHA-GA-11-8492)',
    isOnline: true,
    todayEarnings: parseFloat(localStorage.getItem('uber_react_driver_earnings')) || 3450.00,
    tripsCompleted: parseInt(localStorage.getItem('uber_react_driver_trips')) || 12,
  }));

  // Disputes & Customer Complaints
  const [disputes, setDisputes] = useState(() => [
    {
      id: 'TKT-9201',
      userName: 'Nazmus Sakib (Customer)',
      userPhone: '+880 1711-234567',
      tripId: 'TRIP-8492 (Gulshan ➔ Airport)',
      category: 'Driver Overcharged',
      details: 'Driver took Mohakhali flyover traffic route instead of expressway and charged extra ৳ 120.',
      status: 'PENDING',
      refundAmount: 120.00,
      adminNote: '',
      date: '10 mins ago'
    },
    {
      id: 'TKT-8842',
      userName: 'Tanvir Ahmed (Customer)',
      userPhone: '+880 1819-987654',
      tripId: 'TRIP-7921 (Dhanmondi ➔ Banani)',
      category: 'AC Broken',
      details: 'Car AC was completely non-functional on Uber Comfort.',
      status: 'RESOLVED',
      refundAmount: 80.00,
      adminNote: 'Verified vehicle AC telemetry. Refunded ৳ 80 to rider wallet.',
      date: 'Yesterday'
    }
  ]);

  // Route state
  const [route, setRoute] = useState({
    pickup: { name: 'Gulshan 2, Dhaka', lat: 23.7925, lng: 90.4078 },
    dest: { name: 'Hazrat Shahjalal Int. Airport', lat: 23.8433, lng: 90.4039 },
    distanceKm: 11.4,
    durationMins: 28,
    selectedCar: 'uberx',
  });

  // Toasts
  const [toasts, setToasts] = useState([]);

  // Theme Sync
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('uber_react_theme', theme);
  }, [theme]);

  // Toast Helper
  const showToast = (message, type = 'info') => {
    const id = Date.now() + Math.random();
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 3200);
  };

  // Toggle Theme
  const toggleTheme = () => {
    setTheme(prev => (prev === 'light' ? 'dark' : 'light'));
    showToast(`Switched to ${theme === 'light' ? 'DARK' : 'LIGHT'} mode`);
  };

  // Enter Portal
  const enterPortal = (role) => {
    setSelectedAuthRole(role);
    setCurrentScreen(role);
    if (role === 'customer') {
      showToast('Welcome Nazmus! Logged in as Customer (Passenger).');
    } else if (role === 'driver') {
      showToast('Welcome Mohammad Rafiq! Driver portal online.');
    } else if (role === 'admin') {
      showToast('Welcome Super Admin! Company HQ Control Panel active.');
    }
  };

  // Log Out to Auth Gate
  const logOutToGate = () => {
    setCurrentScreen('auth');
    showToast('Logged out successfully.');
  };

  // Update Admin Pricing & Auto-Sync with Coupons
  const updateAdminPricing = (newPricing) => {
    setAdminPricing(newPricing);
    localStorage.setItem('uber_react_pricing', JSON.stringify(newPricing));

    // Update 1st coupon to reflect new settings
    setCoupons(prev => {
      const updated = [...prev];
      if (updated.length > 0) {
        updated[0] = {
          ...updated[0],
          code: newPricing.couponCode,
          discount: newPricing.storeDiscount,
          maxCap: newPricing.bkashCashback,
          title: `${newPricing.storeDiscount}% Platform Discount`
        };
      }
      localStorage.setItem('uber_react_coupons', JSON.stringify(updated));
      return updated;
    });
  };

  // Add New Coupon
  const addCoupon = (code, discount, maxCap) => {
    const newCoupon = {
      code: code.toUpperCase(),
      discount: parseFloat(discount),
      maxCap: parseFloat(maxCap) || 150,
      status: 'Active',
      title: `${discount}% Promo Discount`
    };
    setCoupons(prev => {
      const updated = [newCoupon, ...prev];
      localStorage.setItem('uber_react_coupons', JSON.stringify(updated));
      return updated;
    });
    showToast(`🎟️ New coupon "${code.toUpperCase()}" published!`);
  };

  // Delete Coupon
  const deleteCoupon = (index) => {
    setCoupons(prev => {
      const updated = prev.filter((_, i) => i !== index);
      localStorage.setItem('uber_react_coupons', JSON.stringify(updated));
      return updated;
    });
    showToast('Coupon deleted');
  };

  // Apply Coupon to Customer
  const applyCoupon = (coupon) => {
    setCustomer(prev => ({ ...prev, appliedCoupon: coupon }));
    showToast(`🎉 Coupon ${coupon.code} applied to your ride!`);
  };

  const removeCoupon = () => {
    setCustomer(prev => ({ ...prev, appliedCoupon: null }));
    showToast('Coupon removed');
  };

  // Customer Wallet Topup
  const topupWallet = (amount) => {
    setCustomer(prev => {
      const newBal = prev.walletBalance + amount;
      localStorage.setItem('uber_react_wallet', newBal);
      return { ...prev, walletBalance: newBal };
    });
    showToast(`৳ ${amount.toFixed(2)} added to your Uber Cash balance!`);
  };

  // Customer Submit Complaint
  const submitComplaint = (category, tripId, details) => {
    const newTicket = {
      id: `TKT-${Math.floor(1000 + Math.random() * 9000)}`,
      userName: customer.name,
      userPhone: customer.phone,
      tripId: tripId || 'TRIP-8492 (Gulshan ➔ Airport)',
      category,
      details,
      status: 'PENDING',
      refundAmount: 120.00,
      adminNote: '',
      date: 'Just now'
    };
    setDisputes(prev => [newTicket, ...prev]);
    showToast('✅ Complaint submitted! Admin HQ will review and credit refund.');
  };

  // Admin Resolve Dispute
  const resolveDispute = (ticketId, customRefund) => {
    const refund = parseFloat(customRefund) || 0;
    setDisputes(prev => prev.map(d => (d.id === ticketId ? { ...d, status: 'RESOLVED', refundAmount: refund } : d)));
    
    // Credit customer wallet
    setCustomer(prev => {
      const newBal = prev.walletBalance + refund;
      localStorage.setItem('uber_react_wallet', newBal);
      return { ...prev, walletBalance: newBal };
    });

    showToast(`✅ Dispute resolved! ৳ ${refund} credited to customer wallet.`);
  };

  // Driver Toggle Online
  const toggleDriverOnline = () => {
    setDriver(prev => {
      const nextOnline = !prev.isOnline;
      showToast(nextOnline ? 'You are now ONLINE' : 'You are now OFFLINE');
      return { ...prev, isOnline: nextOnline };
    });
  };

  // Driver Accept Trip
  const acceptDriverTrip = (fare = 342.00) => {
    setDriver(prev => {
      const newEarnings = prev.todayEarnings + fare;
      const newTrips = prev.tripsCompleted + 1;
      localStorage.setItem('uber_react_driver_earnings', newEarnings);
      localStorage.setItem('uber_react_driver_trips', newTrips);
      return { ...prev, todayEarnings: newEarnings, tripsCompleted: newTrips };
    });
    showToast('Trip Accepted! Navigating to pick up passenger...');
  };

  // Compute live vehicle fares based on admin pricing & applied coupon
  const calculateFare = (carKey) => {
    const rate = VEHICLE_RATES[carKey];
    if (!rate) return { originalFare: 0, finalFare: 0 };

    const dist = route.distanceKm;
    const p = adminPricing;
    const originalFare = Math.round(rate.base + (dist * rate.perKm) + p.shippingCost);
    let discountAmt = Math.round(originalFare * (p.storeDiscount / 100));
    let finalFare = Math.max(40, originalFare - discountAmt);

    if (customer.appliedCoupon) {
      const c = customer.appliedCoupon;
      const extraDisc = Math.min(c.maxCap, Math.round(finalFare * (c.discount / 100)));
      finalFare = Math.max(30, finalFare - extraDisc);
    }

    return { originalFare, finalFare };
  };

  return (
    <AppContext.Provider
      value={{
        theme,
        toggleTheme,
        currentScreen,
        selectedAuthRole,
        setSelectedAuthRole,
        enterPortal,
        logOutToGate,
        adminPricing,
        updateAdminPricing,
        coupons,
        addCoupon,
        deleteCoupon,
        customer,
        applyCoupon,
        removeCoupon,
        topupWallet,
        submitComplaint,
        driver,
        toggleDriverOnline,
        acceptDriverTrip,
        disputes,
        resolveDispute,
        route,
        setRoute,
        calculateFare,
        toasts,
        showToast,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => useContext(AppContext);
