import React, { useState } from 'react';
import { useApp, VEHICLE_RATES } from '../../context/AppContext';
import { LiveMap } from './LiveMap';
import { RideSimulationModal } from './RideSimulationModal';
import { CustomerAccountModal } from './CustomerAccountModal';
import { MapPin, Navigation, ArrowUpDown, Tag, Sparkles, X, ChevronRight } from 'lucide-react';

export const CustomerPortal = () => {
  const { customer, adminPricing, removeCoupon, calculateFare, route, setRoute } = useApp();
  const [selectedCar, setSelectedCar] = useState('uberx');
  const [isSimModalOpen, setIsSimModalOpen] = useState(false);
  const [isAccountModalOpen, setIsAccountModalOpen] = useState(false);
  const [accountTab, setAccountTab] = useState('coupons');
  const [pickupInput, setPickupInput] = useState(route.pickup.name);
  const [destInput, setDestInput] = useState(route.dest.name);

  const dhakaChips = [
    { label: 'Airport (DAC)', dest: 'Hazrat Shahjalal Int. Airport', lat: 23.8433, lng: 90.4039, dist: 11.4 },
    { label: 'Dhanmondi 27', dest: 'Dhanmondi 27, Dhaka', lat: 23.7510, lng: 90.3768, dist: 8.2 },
    { label: 'Banani 11', dest: 'Road 11, Banani', lat: 23.7937, lng: 90.4048, dist: 2.5 },
    { label: 'Uttara Sec 3', dest: 'Sector 3, Uttara', lat: 23.8681, lng: 90.3980, dist: 14.8 },
  ];

  const handleChipClick = (chip) => {
    setDestInput(chip.dest);
    setRoute(prev => ({
      ...prev,
      dest: { name: chip.dest, lat: chip.lat, lng: chip.lng },
      distanceKm: chip.dist,
    }));
  };

  const handleSwap = () => {
    setPickupInput(destInput);
    setDestInput(pickupInput);
    setRoute(prev => ({
      ...prev,
      pickup: prev.dest,
      dest: prev.pickup,
    }));
  };

  const selectedVehicleRate = VEHICLE_RATES[selectedCar];
  const { finalFare } = calculateFare(selectedCar);

  return (
    <div className="flex flex-1 flex-col p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto w-full">
      
      {/* Top Announcement Strip */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-gradient-to-r from-emerald-500/10 via-emerald-500/5 to-transparent border border-emerald-500/20 p-3.5 px-5 dark:border-emerald-500/30">
        <div className="flex items-center gap-2.5 text-xs sm:text-sm font-bold text-gray-800 dark:text-neutral-200">
          <span className="flex h-2 w-2 rounded-full bg-emerald-500 pulse-green-dot" />
          <span>
            Special Offer Active: <strong className="text-emerald-700 dark:text-emerald-400">{adminPricing.storeDiscount}% Store Discount</strong> & <strong className="text-emerald-700 dark:text-emerald-400">৳ {adminPricing.bkashCashback} bKash Cashback</strong>!
          </span>
        </div>
        <button
          onClick={() => {
            setAccountTab('coupons');
            setIsAccountModalOpen(true);
          }}
          className="flex items-center gap-1 text-xs font-black text-emerald-700 hover:underline dark:text-emerald-400"
        >
          <span>View All Coupons</span>
          <ChevronRight size={14} />
        </button>
      </div>

      {/* Main Booking Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-[600px] w-full">
        
        {/* Left Booking Panel */}
        <div className="lg:col-span-5 flex flex-col justify-between rounded-3xl border border-gray-200 bg-white p-5 sm:p-6 shadow-md dark:border-neutral-800 dark:bg-neutral-900">
          
          <div className="space-y-4">
            <div>
              <h2 className="text-xl font-black text-gray-900 dark:text-white">Where can we take you?</h2>
              <p className="text-xs text-gray-500 dark:text-neutral-400">Request a ride, hop in, and go.</p>
            </div>

            {/* Inputs */}
            <div className="space-y-2 relative">
              <div className="flex items-center rounded-xl border border-gray-200 bg-gray-50 px-3 py-2.5 dark:border-neutral-700 dark:bg-neutral-800">
                <div className="mr-2.5 flex h-4 w-4 items-center justify-center">
                  <span className="h-2 w-2 rounded-full bg-black dark:bg-white" />
                </div>
                <input
                  type="text"
                  value={pickupInput}
                  onChange={(e) => setPickupInput(e.target.value)}
                  placeholder="Enter pickup location"
                  className="w-full bg-transparent text-xs font-bold text-gray-900 focus:outline-none dark:text-white"
                />
                <button
                  type="button"
                  className="rounded-md border border-gray-200 bg-white px-2 py-1 text-[10px] font-bold text-gray-600 shadow-sm dark:border-neutral-600 dark:bg-neutral-700 dark:text-neutral-300"
                >
                  GPS
                </button>
              </div>

              <div className="flex items-center rounded-xl border border-gray-200 bg-gray-50 px-3 py-2.5 dark:border-neutral-700 dark:bg-neutral-800">
                <div className="mr-2.5 flex h-4 w-4 items-center justify-center">
                  <span className="h-2 w-2 rounded bg-red-500" />
                </div>
                <input
                  type="text"
                  value={destInput}
                  onChange={(e) => setDestInput(e.target.value)}
                  placeholder="Where to?"
                  className="w-full bg-transparent text-xs font-bold text-gray-900 focus:outline-none dark:text-white"
                />
                <button
                  type="button"
                  onClick={handleSwap}
                  className="rounded-md border border-gray-200 bg-white px-2 py-1 text-[10px] font-bold text-gray-600 shadow-sm dark:border-neutral-600 dark:bg-neutral-700 dark:text-neutral-300"
                  title="Swap pickup and destination"
                >
                  <ArrowUpDown size={12} />
                </button>
              </div>
            </div>

            {/* Dhaka Landmark Quick Chips */}
            <div className="flex flex-wrap items-center gap-1.5 pt-1">
              <span className="text-[11px] font-bold text-gray-400">Quick:</span>
              {dhakaChips.map((chip, idx) => (
                <button
                  key={idx}
                  onClick={() => handleChipClick(chip)}
                  className="rounded-full border border-gray-200 bg-gray-50 px-3 py-1 text-[11px] font-semibold text-gray-700 transition hover:border-black hover:bg-black hover:text-white dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-300 dark:hover:border-white dark:hover:bg-white dark:hover:text-black"
                >
                  {chip.label}
                </button>
              ))}
            </div>

            {/* Applied Coupon Strip */}
            {customer.appliedCoupon && (
              <div className="flex items-center justify-between rounded-xl border border-dashed border-emerald-500 bg-emerald-50 p-2.5 px-3.5 text-xs dark:bg-emerald-950/40">
                <div className="flex items-center gap-2">
                  <Tag size={15} className="text-emerald-700 dark:text-emerald-400" />
                  <div>
                    <strong className="font-extrabold text-emerald-800 dark:text-emerald-300">
                      {customer.appliedCoupon.code} Applied
                    </strong>
                    <span className="block text-[10px] text-emerald-700 dark:text-emerald-400 font-medium">
                      {customer.appliedCoupon.discount}% Discount (Max ৳ {customer.appliedCoupon.maxCap})
                    </span>
                  </div>
                </div>
                <button
                  onClick={removeCoupon}
                  className="rounded-full p-1 text-emerald-700 hover:bg-emerald-100 dark:text-emerald-400 dark:hover:bg-emerald-900"
                >
                  <X size={14} />
                </button>
              </div>
            )}

            {/* Vehicle Options List */}
            <div className="space-y-2 pt-2 max-h-56 overflow-y-auto pr-1">
              {Object.keys(VEHICLE_RATES).map((key) => {
                const v = VEHICLE_RATES[key];
                const { originalFare, finalFare: fare } = calculateFare(key);
                const isSelected = selectedCar === key;

                return (
                  <div
                    key={key}
                    onClick={() => setSelectedCar(key)}
                    className={`flex cursor-pointer items-center justify-between rounded-2xl border-2 p-3 transition-all ${
                      isSelected
                        ? 'border-black bg-gray-50 shadow-sm dark:border-white dark:bg-neutral-800'
                        : 'border-transparent bg-gray-50/50 hover:bg-gray-100 dark:bg-neutral-800/40 dark:hover:bg-neutral-800'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{v.icon}</span>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs font-extrabold text-gray-900 dark:text-white">{v.name}</h4>
                          <span className="text-[10px] text-gray-400 font-semibold">{v.capacity}</span>
                        </div>
                        <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold">{v.eta}</p>
                      </div>
                    </div>

                    <div className="text-right">
                      {originalFare > fare && (
                        <span className="block text-[10px] text-gray-400 line-through">৳ {originalFare}</span>
                      )}
                      <strong className="text-sm font-black text-gray-900 dark:text-white">৳ {fare}</strong>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Bottom Actions */}
          <div className="mt-4 border-t border-gray-100 pt-4 space-y-3 dark:border-neutral-800">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-gray-600 dark:text-neutral-400">
                bKash (৳ {adminPricing.bkashCashback} Cashback) / Uber Cash (৳ {Math.round(customer.walletBalance)})
              </span>
              <button
                onClick={() => {
                  setAccountTab('coupons');
                  setIsAccountModalOpen(true);
                }}
                className="font-bold text-black hover:underline dark:text-white"
              >
                🎟️ Coupons
              </button>
            </div>

            <button
              onClick={() => setIsSimModalOpen(true)}
              className="flex w-full items-center justify-between rounded-2xl bg-black py-4 px-6 text-sm font-extrabold text-white shadow-xl transition hover:bg-neutral-800 dark:bg-white dark:text-black dark:hover:bg-neutral-200"
            >
              <span>Request {selectedVehicleRate?.name}</span>
              <span className="rounded-full bg-white/20 px-3 py-1 text-xs dark:bg-black/20">
                ৳ {finalFare}
              </span>
            </button>
          </div>

        </div>

        {/* Right Live Map */}
        <div className="lg:col-span-7 h-full">
          <LiveMap isSimulating={isSimModalOpen} />
        </div>

      </div>

      {/* Ride Simulation Modal */}
      <RideSimulationModal
        isOpen={isSimModalOpen}
        onClose={() => setIsSimModalOpen(false)}
        selectedVehicle={selectedCar}
      />

      {/* Customer Account & Coupons Modal */}
      <CustomerAccountModal
        isOpen={isAccountModalOpen}
        onClose={() => setIsAccountModalOpen(false)}
        initialTab={accountTab}
      />

    </div>
  );
};
