import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { WebSocketServer, WebSocket } from 'ws';
import { createServer as createViteServer } from 'vite';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const PORT = 3000;

app.use(express.json());

// ==========================================
// IN-MEMORY DATA STORE
// ==========================================

const users = [
  {
    id: 'usr-1',
    name: 'Tamim Iqbal',
    email: 'user@foodpanda.com',
    phone: '01711223344',
    role: 'customer'
  },
  {
    id: 'adm-1',
    name: 'Foodpanda Admin',
    email: 'admin@foodpanda.com',
    phone: '01888990011',
    role: 'admin'
  }
];

let restaurants = [
  {
    id: 1,
    name: "Kacchi Bhai",
    img: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80",
    rating: 4.9,
    time: "25-35 min",
    fee: 40,
    cats: ["Biriyani", "Mughlai", "Bengali"],
    cuisine: "Kacchi Biriyani · Mughlai · Dhakaiya Special",
    promo: "Best Seller",
    menu: [
      { id: 101, name: "Kacchi Biriyani (Full)", desc: "Traditional Dhaka-style kacchi with tender mutton and aromatic chinigura rice", price: 350, popular: true },
      { id: 102, name: "Kacchi Biriyani (Half)", desc: "Half plate kacchi with 1 pc mutton — perfect for single person", price: 200, popular: true },
      { id: 103, name: "Beef Tehari", desc: "Old Dhaka recipe spicy mustard oil beef tehari", price: 160 },
      { id: 104, name: "Mutton Rezala", desc: "Creamy white gravy mutton cooked with cashews and ghee", price: 280 },
      { id: 105, name: "Special Shahi Borhani (250ml)", desc: "Traditional Dhakaiya spiced sour yogurt digestive drink", price: 40, popular: true },
      { id: 106, name: "Shahi Jorda", desc: "Sweet saffron rice garnished with baby sweets and nuts", price: 60 }
    ]
  },
  {
    id: 2,
    name: "Sultan's Dine",
    img: "https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=800&q=80",
    rating: 4.8,
    time: "30-40 min",
    fee: 50,
    cats: ["Biriyani", "Bengali", "Mughlai"],
    cuisine: "Biriyani · Feast Platter · Mughlai Delicacies",
    promo: "Popular",
    menu: [
      { id: 201, name: "Mutton Kacchi Feast", desc: "Sultan's royal mutton kacchi served with jali kabab and borhani", price: 420, popular: true },
      { id: 202, name: "Morog Polao Special", desc: "Whole golden chicken leg slow-cooked with aromatic polao", price: 260, popular: true },
      { id: 203, name: "Beef Bhuna Khichuri", desc: "Rich spicy beef curry served with ghee bhuna khichuri", price: 250 },
      { id: 204, name: "Mutton Chaap Roast", desc: "Pan-fried spiced mutton ribs in rich gravy", price: 210 },
      { id: 205, name: "Shahi Tukra Dessert", desc: "Fried bread slices steeped in condensed milk, cardamom, and pistachios", price: 80 }
    ]
  },
  {
    id: 3,
    name: "Star Kabab & Restaurant",
    img: "https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?auto=format&fit=crop&w=800&q=80",
    rating: 4.7,
    time: "20-30 min",
    fee: 35,
    cats: ["Kebab", "Mughlai", "Bengali"],
    cuisine: "Kebab · Charcoal Tandoor · Bengali Curries",
    menu: [
      { id: 301, name: "Chicken Tikka Kebab (8pcs)", desc: "Charcoal grilled marinated boneless chicken in red spices", price: 280, popular: true },
      { id: 302, name: "Mutton Seekh Kebab", desc: "Juicy minced mutton kebab seasoned with fresh herbs", price: 320, popular: true },
      { id: 303, name: "Beef Boti Kebab", desc: "Tender beef chunks grilled on skewers over charcoal", price: 260 },
      { id: 304, name: "Butter Garlic Naan", desc: "Tandoori flatbread brushed with molten butter and garlic", price: 50 },
      { id: 305, name: "Sweet Lassi (Large)", desc: "Thick creamy curd lassi with saffron aroma", price: 60 }
    ]
  },
  {
    id: 4,
    name: "Chillox Burgers",
    img: "https://images.unsplash.com/photo-1571091718767-18b5b1457add?auto=format&fit=crop&w=800&q=80",
    rating: 4.6,
    time: "15-25 min",
    fee: 30,
    cats: ["Burger", "Street Food"],
    cuisine: "Burgers · Loaded Fries · Shakes",
    promo: "20% OFF",
    menu: [
      { id: 401, name: "Smash Beef Bacon Burger", desc: "Double smash patties, melted cheddar, smoky beef bacon, chillox sauce", price: 340, popular: true },
      { id: 402, name: "Crispy Chicken Zinger", desc: "Ultra-crispy fried chicken thigh fillet, coleslaw, hot mayo", price: 240, popular: true },
      { id: 403, name: "Loaded Naga Cheese Fries", desc: "Golden crinkle fries drenched in cheese sauce and naga chili kick", price: 190 },
      { id: 404, name: "Hot Buffalo Wings (6pcs)", desc: "Crispy fried wings tossed in fiery buffalo hot sauce", price: 260 },
      { id: 405, name: "Oreo Belgian Thick Shake", desc: "Thick hand-spun ice cream shake with crushed Oreo cookies", price: 160 }
    ]
  },
  {
    id: 5,
    name: "Pizza Hut",
    img: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=800&q=80",
    rating: 4.5,
    time: "25-35 min",
    fee: 45,
    cats: ["Pizza"],
    cuisine: "Pan Pizza · Pasta · Cheesy Appetizers",
    promo: "BOGO Offer",
    menu: [
      { id: 501, name: "Chicken Supreme Pizza (Medium)", desc: "Tikka chicken, bell peppers, black olives, onions and mozzarella", price: 680, popular: true },
      { id: 502, name: "Pepperoni Lover's Pizza", desc: "Layered with double beef pepperoni slices and gooey cheese", price: 720 },
      { id: 503, name: "Cheesy Stuffed Garlic Bread", desc: "Warm baked bread sticks filled with stringy mozzarella", price: 220 },
      { id: 504, name: "Spicy Creamy Chicken Pasta", desc: "Penne pasta baked in spicy pink sauce with grilled chicken", price: 360 }
    ]
  },
  {
    id: 6,
    name: "Panshi Bengali Kitchen",
    img: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?auto=format&fit=crop&w=800&q=80",
    rating: 4.8,
    time: "20-30 min",
    fee: 35,
    cats: ["Bengali"],
    cuisine: "Traditional Bengali · Ilish Curry · Bhartas",
    menu: [
      { id: 601, name: "Padma Ilish Bhuna", desc: "Authentic Hilsha fish steak simmered in mustard and green chili gravy", price: 460, popular: true },
      { id: 602, name: "Chitol Muitha Curry", desc: "Featherback fish dumplings in fragrant rich tomato and ginger gravy", price: 380 },
      { id: 603, name: "Slow-Cooked Beef Kala Bhuna", desc: "Chittagong-style caramelized dry beef bhuna with roasted spices", price: 320, popular: true },
      { id: 604, name: "Assorted Bharta Platter (4 types)", desc: "Alu, begun, chingri, and tomato bhartas with hot steamed rice", price: 180 }
    ]
  },
  {
    id: 7,
    name: "Thai Orchid",
    img: "https://images.unsplash.com/photo-1562565652-a0d8f0c59eb4?auto=format&fit=crop&w=800&q=80",
    rating: 4.6,
    time: "25-35 min",
    fee: 45,
    cats: ["Thai", "Chinese"],
    cuisine: "Authentic Thai · Wok Noodling · Tom Yum",
    menu: [
      { id: 701, name: "Spicy Tom Yum Prawn Soup", desc: "Sour and spicy lemongrass soup with tiger prawns and galangal", price: 260, popular: true },
      { id: 702, name: "Thai Pad Kra Pao Chicken", desc: "Wok-fried minced chicken with holy basil and sunny fried egg", price: 290 },
      { id: 703, name: "Traditional Pad Thai Noodles", desc: "Rice noodles stir-fried with crushed peanuts, bean sprouts, lime", price: 310, popular: true },
      { id: 704, name: "Sweet Mango Sticky Rice", desc: "Fresh sweet mango slices on coconut cream infused sticky rice", price: 170 }
    ]
  },
  {
    id: 8,
    name: "Mithai Ghor & Sweets",
    img: "https://images.unsplash.com/photo-1551024601-bec78aea704b?auto=format&fit=crop&w=800&q=80",
    rating: 4.7,
    time: "15-20 min",
    fee: 25,
    cats: ["Dessert", "Bengali"],
    cuisine: "Traditional Sweets · Mishti Doi · Halwa",
    menu: [
      { id: 801, name: "Traditional Bogra Mishti Doi (Cup)", desc: "Caramelized clay-pot sweet curd from Bogra", price: 60, popular: true },
      { id: 802, name: "Sponge Rosogolla (6pcs)", desc: "Puff-light cottage cheese balls dipped in light cardamom syrup", price: 140, popular: true },
      { id: 803, name: "Porabari Chomchom (4pcs)", desc: "Tangail's famous condensed milk and mawa coated chomchom", price: 160 },
      { id: 804, name: "Crispy Saffron Jilapi (250g)", desc: "Freshly piped spiral jalebis with saffron sugar crystal dip", price: 80 }
    ]
  }
];

let promoRules: Record<string, { code: string; pct?: number; flat?: number; freeDelivery?: boolean; max?: number }> = {
  WELCOME50: { code: 'WELCOME50', pct: 50, max: 200 },
  FREEWEEKEND: { code: 'FREEWEEKEND', flat: 0, freeDelivery: true },
  BOGOFOOD: { code: 'BOGOFOOD', pct: 30, max: 150 },
  PANDA20: { code: 'PANDA20', pct: 20, max: 100 }
};

let riders = [
  { id: 1, name: 'Rafiq Uddin', phone: '+8801719001122', status: 'online', totalDeliveries: 284 },
  { id: 2, name: 'Shakib Al Hasan', phone: '+8801912345678', status: 'on-delivery', totalDeliveries: 198 },
  { id: 3, name: 'Jamal Hossain', phone: '+8801815556677', status: 'online', totalDeliveries: 156 },
  { id: 4, name: 'Tariq Rahman', phone: '+8801614443322', status: 'offline', totalDeliveries: 89 }
];

let orders: any[] = [
  {
    id: 'FPD-724912',
    userId: 'usr-1',
    customerName: 'Tamim Iqbal',
    customerPhone: '01711223344',
    items: [
      { itemId: 101, restId: 1, restName: 'Kacchi Bhai', name: 'Kacchi Biriyani (Full)', price: 350, qty: 2, fee: 40 },
      { itemId: 105, restId: 1, restName: 'Kacchi Bhai', name: 'Special Shahi Borhani (250ml)', price: 40, qty: 2, fee: 40 }
    ],
    totals: { sub: 780, fee: 40, vat: 39, disc: 200, total: 659 },
    address: 'House 42, Road 9/A, Dhanmondi, Dhaka',
    notes: 'Please ring bell twice on 4th floor.',
    paymentMethod: 'bkash',
    paymentStatus: 'paid',
    transactionId: 'BKASH-9482910',
    placedAt: new Date(Date.now() - 25 * 60000).toISOString(),
    estDelivery: new Date(Date.now() + 10 * 60000).toISOString(),
    status: 'on-the-way',
    rider: { id: 1, name: 'Rafiq Uddin', phone: '+8801719001122' }
  }
];

// ==========================================
// WEBSOCKET REAL-TIME BROADCAST
// ==========================================
const wss = new WebSocketServer({ server });

function broadcast(data: any) {
  const payload = JSON.stringify(data);
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(payload);
    }
  });
}

wss.on('connection', (ws) => {
  // Send welcome ack
  ws.send(JSON.stringify({ type: 'CONNECTED', message: 'Connected to foodpanda real-time stream' }));

  ws.on('message', (msg) => {
    try {
      const data = JSON.parse(msg.toString());
      if (data.type === 'PING') {
        ws.send(JSON.stringify({ type: 'PONG' }));
      }
    } catch {
      // ignore
    }
  });
});

// ==========================================
// REST API ROUTES
// ==========================================

// Health
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// Auth login
app.post('/api/auth/login', (req, res) => {
  const { email, password, role } = req.body;
  if (!email) {
    return res.status(400).json({ error: 'Email or phone required' });
  }

  const cleanEmail = email.trim().toLowerCase();
  const isAdminRequest = role === 'admin' || cleanEmail.includes('admin');

  let user = users.find(u => u.email.toLowerCase() === cleanEmail);
  if (!user) {
    user = {
      id: 'usr-' + Date.now(),
      name: isAdminRequest ? 'Admin User' : (cleanEmail.split('@')[0] || 'Customer'),
      email: cleanEmail.includes('@') ? cleanEmail : cleanEmail + '@foodpanda.com',
      phone: '01XXXXXXXXX',
      role: isAdminRequest ? 'admin' : 'customer'
    };
    users.push(user);
  }

  res.json({
    user,
    token: 'jwt-token-' + user.id + '-' + Date.now()
  });
});

// Auth register
app.post('/api/auth/register', (req, res) => {
  const { name, email, phone, role } = req.body;
  if (!name || !email) {
    return res.status(400).json({ error: 'Name and email are required' });
  }

  const user = {
    id: 'usr-' + Date.now(),
    name,
    email: email.trim().toLowerCase(),
    phone: phone || '01XXXXXXXXX',
    role: (role === 'admin' ? 'admin' : 'customer') as 'customer' | 'admin'
  };
  users.push(user);
  res.json({ user, token: 'jwt-token-' + user.id + '-' + Date.now() });
});

// Restaurants
app.get('/api/restaurants', (req, res) => {
  res.json(restaurants);
});

app.post('/api/restaurants', (req, res) => {
  const { name, img, cuisine, cats, fee, time } = req.body;
  if (!name) {
    return res.status(400).json({ error: 'Restaurant name required' });
  }

  const newRest = {
    id: Date.now(),
    name,
    img: img || 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80',
    rating: 4.8,
    time: time || '20-30 min',
    fee: Number(fee) || 35,
    cats: Array.isArray(cats) ? cats : (cats ? cats.split(',').map((s: string) => s.trim()) : ['Bengali']),
    cuisine: cuisine || 'Diverse Delicacies · Fast Food',
    promo: 'New on foodpanda',
    menu: []
  };

  restaurants.push(newRest);
  broadcast({ type: 'RESTAURANTS_UPDATED', count: restaurants.length });
  res.status(201).json(newRest);
});

app.delete('/api/restaurants/:id', (req, res) => {
  const id = Number(req.params.id);
  restaurants = restaurants.filter(r => r.id !== id);
  broadcast({ type: 'RESTAURANTS_UPDATED', count: restaurants.length });
  res.json({ success: true, id });
});

// Restaurant Menu Item
app.post('/api/restaurants/:id/menu', (req, res) => {
  const restId = Number(req.params.id);
  const rest = restaurants.find(r => r.id === restId);
  if (!rest) {
    return res.status(404).json({ error: 'Restaurant not found' });
  }

  const { name, desc, price, popular } = req.body;
  if (!name || !price) {
    return res.status(400).json({ error: 'Name and price are required' });
  }

  const item = {
    id: Date.now(),
    name,
    desc: desc || 'Prepared fresh upon ordering with authentic ingredients',
    price: Number(price),
    popular: Boolean(popular)
  };

  rest.menu.push(item);
  broadcast({ type: 'MENU_UPDATED', restId, itemId: item.id });
  res.status(201).json(item);
});

app.delete('/api/restaurants/:id/menu/:itemId', (req, res) => {
  const restId = Number(req.params.id);
  const itemId = Number(req.params.itemId);
  const rest = restaurants.find(r => r.id === restId);
  if (!rest) {
    return res.status(404).json({ error: 'Restaurant not found' });
  }

  rest.menu = rest.menu.filter(m => m.id !== itemId);
  broadcast({ type: 'MENU_UPDATED', restId, itemId });
  res.json({ success: true, itemId });
});

// Promos
app.get('/api/promos', (req, res) => {
  res.json(promoRules);
});

app.post('/api/promos', (req, res) => {
  const { code, type, value, max } = req.body;
  if (!code || !value) {
    return res.status(400).json({ error: 'Code and value required' });
  }

  const uppercaseCode = code.trim().toUpperCase();
  const rule = {
    code: uppercaseCode,
    ...(type === 'pct' ? { pct: Number(value), max: Number(max) || 9999 } : { flat: Number(value), max: Number(max) || Number(value) })
  };

  promoRules[uppercaseCode] = rule;
  broadcast({ type: 'PROMOS_UPDATED' });
  res.status(201).json(rule);
});

app.delete('/api/promos/:code', (req, res) => {
  const code = req.params.code.toUpperCase();
  delete promoRules[code];
  broadcast({ type: 'PROMOS_UPDATED' });
  res.json({ success: true, code });
});

// Riders
app.get('/api/riders', (req, res) => {
  res.json(riders);
});

app.post('/api/riders', (req, res) => {
  const { name, phone, status } = req.body;
  if (!name || !phone) {
    return res.status(400).json({ error: 'Name and phone required' });
  }

  const rider = {
    id: Date.now(),
    name,
    phone,
    status: (status || 'online') as 'online' | 'offline' | 'on-delivery',
    totalDeliveries: 0
  };

  riders.push(rider);
  broadcast({ type: 'RIDERS_UPDATED', rider });
  res.status(201).json(rider);
});

app.put('/api/riders/:id', (req, res) => {
  const id = Number(req.params.id);
  const rider = riders.find(r => r.id === id);
  if (!rider) {
    return res.status(404).json({ error: 'Rider not found' });
  }

  if (req.body.status) rider.status = req.body.status;
  if (req.body.totalDeliveries !== undefined) rider.totalDeliveries = Number(req.body.totalDeliveries);

  broadcast({ type: 'RIDERS_UPDATED', rider });
  res.json(rider);
});

app.delete('/api/riders/:id', (req, res) => {
  const id = Number(req.params.id);
  riders = riders.filter(r => r.id !== id);
  broadcast({ type: 'RIDERS_UPDATED', deletedId: id });
  res.json({ success: true, id });
});

// Orders
app.get('/api/orders', (req, res) => {
  const { userId } = req.query;
  if (userId) {
    const userOrders = orders.filter(o => o.userId === userId);
    return res.json(userOrders);
  }
  res.json(orders);
});

// Secure Payment Gateway Processing endpoint
app.post('/api/payments/process', (req, res) => {
  const { paymentMethod, amount, cardDetails, mobileNumber } = req.body;

  // Validate payment inputs
  if (paymentMethod === 'card') {
    if (!cardDetails || !cardDetails.cardNumber || cardDetails.cardNumber.replace(/\s/g, '').length < 15) {
      return res.status(400).json({ success: false, error: 'Invalid card number' });
    }
  }

  // Generate secure transaction hash
  const prefix = paymentMethod.toUpperCase();
  const txId = `${prefix}-${Math.floor(10000000 + Math.random() * 90000000)}`;

  res.json({
    success: true,
    transactionId: txId,
    amount: Number(amount),
    status: 'COMPLETED',
    gateway: paymentMethod === 'bkash' ? 'bKash Merchant Gateway v3.2'
             : paymentMethod === 'nagad' ? 'Nagad Direct Gateway'
             : paymentMethod === 'card' ? 'Visa/Mastercard 3D-Secure 2.0'
             : 'Cash On Delivery Escrow',
    processedAt: new Date().toISOString()
  });
});

// Create Order
app.post('/api/orders', (req, res) => {
  const { userId, customerName, customerPhone, items, totals, address, notes, paymentMethod, transactionId } = req.body;
  if (!items || !items.length || !address) {
    return res.status(400).json({ error: 'Order items and delivery address are required' });
  }

  // Auto assign online rider
  const availableRider = riders.find(r => r.status === 'online') || riders[0];

  const now = new Date();
  const estDelivery = new Date(now.getTime() + 32 * 60000);

  const order = {
    id: 'FPD-' + Math.floor(100000 + Math.random() * 900000),
    userId: userId || 'usr-1',
    customerName: customerName || 'Valued Customer',
    customerPhone: customerPhone || '01XXXXXXXXX',
    items,
    totals: totals || { sub: 0, fee: 35, vat: 0, disc: 0, total: 35 },
    address,
    notes: notes || '',
    paymentMethod: paymentMethod || 'bkash',
    paymentStatus: paymentMethod === 'cod' ? 'pending' : 'paid',
    transactionId: transactionId || `TXN-${Date.now()}`,
    placedAt: now.toISOString(),
    estDelivery: estDelivery.toISOString(),
    status: 'placed',
    rider: availableRider ? { id: availableRider.id, name: availableRider.name, phone: availableRider.phone } : undefined
  };

  orders.unshift(order);

  // Broadcast real-time order created to WebSockets
  broadcast({
    type: 'ORDER_CREATED',
    order,
    notification: {
      id: 'notif-' + Date.now(),
      title: 'New Order Received! 🛍️',
      body: `Order #${order.id} from ${order.customerName} for ৳${order.totals.total}`,
      orderId: order.id,
      timestamp: now.toISOString()
    }
  });

  res.status(201).json(order);
});

// Update Order Status
app.patch('/api/orders/:id/status', (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  const order = orders.find(o => o.id === id);
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }

  order.status = status;

  // Status message mapping for push notifications
  const statusMessages: Record<string, string> = {
    confirmed: 'Restaurant has confirmed your order! 👨‍🍳',
    preparing: 'Your delicious food is being prepared in the kitchen 🍳',
    'on-the-way': `${order.rider?.name || 'Rider'} has picked up your food and is on the way! 🛵`,
    delivered: 'Your order has been delivered! Enjoy your meal 😋',
    cancelled: 'Your order has been cancelled.'
  };

  const notification = {
    id: 'notif-' + Date.now(),
    title: `Order #${order.id} Update`,
    body: statusMessages[status] || `Order status updated to ${status}`,
    orderId: order.id,
    timestamp: new Date().toISOString()
  };

  // Broadcast real-time event
  broadcast({
    type: 'ORDER_STATUS_UPDATED',
    order,
    notification
  });

  res.json({ success: true, order, notification });
});

// ==========================================
// VITE MIDDLEWARE & SPA FALLBACK
// ==========================================
async function start() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Foodpanda Full-Stack server running on http://0.0.0.0:${PORT}`);
  });
}

start();
