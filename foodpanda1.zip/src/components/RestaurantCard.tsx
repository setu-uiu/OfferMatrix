import React from 'react';
import { Restaurant } from '../types';
import { Star, Clock, Heart, Bike } from 'lucide-react';

interface RestaurantCardProps {
  restaurant: Restaurant;
  isFavorite: boolean;
  onSelect: (id: number) => void;
  onToggleFavorite: (id: number, e: React.MouseEvent) => void;
}

export const RestaurantCard: React.FC<RestaurantCardProps> = ({
  restaurant,
  isFavorite,
  onSelect,
  onToggleFavorite,
}) => {
  return (
    <div
      onClick={() => onSelect(restaurant.id)}
      className="group bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-xs hover:shadow-xl hover:-translate-y-1 transition-all duration-300 cursor-pointer flex flex-col"
      id={`restaurant-card-${restaurant.id}`}
    >
      {/* Image Wrap */}
      <div className="relative h-44 sm:h-48 overflow-hidden bg-gray-100">
        <img
          src={restaurant.img}
          alt={restaurant.name}
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
        />

        {/* Promo tag */}
        {restaurant.promo && (
          <span className="absolute top-3 left-3 bg-[#E21B70] text-white text-[11px] font-extrabold px-2.5 py-1 rounded-md shadow-sm uppercase tracking-wider">
            {restaurant.promo}
          </span>
        )}

        {/* Delivery Time Badge */}
        <div className="absolute bottom-3 right-3 bg-black/75 backdrop-blur-xs text-white text-xs font-semibold px-2.5 py-1 rounded-lg flex items-center gap-1.5">
          <Clock className="w-3.5 h-3.5 text-pink-400" />
          <span>{restaurant.time}</span>
        </div>

        {/* Favorite Heart Button */}
        <button
          type="button"
          onClick={(e) => onToggleFavorite(restaurant.id, e)}
          className={`absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 backdrop-blur-xs flex items-center justify-center transition shadow-sm hover:scale-110 cursor-pointer ${
            isFavorite ? 'text-[#E21B70]' : 'text-gray-400 hover:text-[#E21B70]'
          }`}
          title={isFavorite ? 'Remove from favorites' : 'Save to favorites'}
        >
          <Heart className={`w-4 h-4 ${isFavorite ? 'fill-[#E21B70]' : ''}`} />
        </button>
      </div>

      {/* Body Info */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between gap-2 mb-1">
            <h3 className="font-bold text-base sm:text-lg text-gray-900 group-hover:text-[#E21B70] transition truncate">
              {restaurant.name}
            </h3>
            <div className="flex items-center gap-1 bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-md text-xs font-black shrink-0">
              <Star className="w-3 h-3 fill-emerald-600 text-emerald-600" />
              <span>{restaurant.rating}</span>
            </div>
          </div>
          <p className="text-xs text-gray-500 line-clamp-1 mb-3">
            {restaurant.cuisine}
          </p>
        </div>

        {/* Footer Meta */}
        <div className="flex items-center justify-between text-xs pt-3 border-t border-gray-50 text-gray-500">
          <div className="flex items-center gap-1.5 font-medium">
            <Bike className="w-3.5 h-3.5 text-gray-400" />
            {restaurant.fee === 0 ? (
              <span className="text-emerald-600 font-bold">Free Delivery</span>
            ) : (
              <span>৳{restaurant.fee} Delivery</span>
            )}
          </div>
          <span className="text-gray-400 text-[11px] font-semibold">
            {restaurant.menu.length} items
          </span>
        </div>
      </div>
    </div>
  );
};
