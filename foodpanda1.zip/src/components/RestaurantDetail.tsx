import React from 'react';
import { Restaurant, CartItem, MenuItem } from '../types';
import { ArrowLeft, Star, Clock, Bike, Heart, Plus, Minus, Flame } from 'lucide-react';

interface RestaurantDetailProps {
  restaurant: Restaurant;
  cart: CartItem[];
  isFavorite: boolean;
  onBack: () => void;
  onAddToCart: (item: MenuItem, rest: Restaurant) => void;
  onUpdateCartQty: (itemId: number, delta: number) => void;
  onToggleFavorite: (id: number) => void;
}

export const RestaurantDetail: React.FC<RestaurantDetailProps> = ({
  restaurant,
  cart,
  isFavorite,
  onBack,
  onAddToCart,
  onUpdateCartQty,
  onToggleFavorite,
}) => {
  const popularItems = restaurant.menu.filter((m) => m.popular);
  const otherItems = restaurant.menu.filter((m) => !m.popular);

  const getItemQty = (itemId: number) => {
    const found = cart.find((c) => c.itemId === itemId && c.restId === restaurant.id);
    return found ? found.qty : 0;
  };

  const renderItemCard = (item: MenuItem) => {
    const qty = getItemQty(item.id);
    return (
      <div
        key={item.id}
        className="bg-white rounded-xl p-4 border border-gray-100 shadow-xs hover:border-pink-200 transition flex items-center justify-between gap-4"
      >
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <h4 className="font-bold text-sm sm:text-base text-gray-900 truncate">
              {item.name}
            </h4>
            {item.popular && (
              <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-700 text-[10px] font-black px-2 py-0.5 rounded-full shrink-0">
                <Flame className="w-3 h-3 fill-amber-500 text-amber-500" /> Bestseller
              </span>
            )}
          </div>
          <p className="text-xs text-gray-500 line-clamp-2 mb-2">{item.desc}</p>
          <div className="text-sm sm:text-base font-extrabold text-[#E21B70]">
            ৳{item.price}
          </div>
        </div>

        {/* Quantity / Add Button */}
        <div className="shrink-0">
          {qty > 0 ? (
            <div className="flex items-center bg-pink-50 rounded-xl border border-pink-200 overflow-hidden">
              <button
                type="button"
                onClick={() => onUpdateCartQty(item.id, -1)}
                className="w-8 h-8 flex items-center justify-center text-[#E21B70] hover:bg-[#E21B70] hover:text-white transition cursor-pointer"
              >
                <Minus className="w-3.5 h-3.5" />
              </button>
              <span className="w-8 text-center text-xs sm:text-sm font-extrabold text-gray-900">
                {qty}
              </span>
              <button
                type="button"
                onClick={() => onUpdateCartQty(item.id, 1)}
                className="w-8 h-8 flex items-center justify-center text-[#E21B70] hover:bg-[#E21B70] hover:text-white transition cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => onAddToCart(item, restaurant)}
              className="px-4 py-2 bg-[#E21B70] hover:bg-[#c4155f] text-white text-xs sm:text-sm font-bold rounded-xl flex items-center gap-1.5 transition shadow-sm cursor-pointer"
            >
              <Plus className="w-4 h-4" /> Add
            </button>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="py-2 sm:py-4">
      {/* Back button */}
      <button
        type="button"
        onClick={onBack}
        className="inline-flex items-center gap-2 text-xs sm:text-sm font-bold text-gray-600 hover:text-[#E21B70] mb-4 transition cursor-pointer"
      >
        <ArrowLeft className="w-4 h-4" /> Back to Restaurants
      </button>

      {/* Hero Banner */}
      <div className="relative h-56 sm:h-72 rounded-2xl overflow-hidden shadow-md mb-6 bg-gray-100">
        <img
          src={restaurant.img}
          alt={restaurant.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent flex items-end p-5 sm:p-7">
          <div className="text-white">
            <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight mb-2">
              {restaurant.name}
            </h1>
            <p className="text-xs sm:text-sm text-white/90 mb-3">{restaurant.cuisine}</p>
            <div className="flex flex-wrap items-center gap-3 text-xs">
              <span className="flex items-center gap-1 bg-emerald-500/90 text-white font-black px-2.5 py-1 rounded-lg">
                <Star className="w-3.5 h-3.5 fill-white" /> {restaurant.rating}
              </span>
              <span className="flex items-center gap-1 bg-white/20 backdrop-blur-md px-2.5 py-1 rounded-lg font-semibold">
                <Clock className="w-3.5 h-3.5" /> {restaurant.time}
              </span>
              <span className="flex items-center gap-1 bg-white/20 backdrop-blur-md px-2.5 py-1 rounded-lg font-semibold">
                <Bike className="w-3.5 h-3.5" /> ৳{restaurant.fee} Delivery
              </span>
            </div>
          </div>
        </div>

        {/* Floating Favorite Button */}
        <button
          type="button"
          onClick={() => onToggleFavorite(restaurant.id)}
          className={`absolute top-4 right-4 px-3.5 py-2 rounded-full backdrop-blur-md flex items-center gap-2 text-xs font-bold transition shadow-sm cursor-pointer ${
            isFavorite
              ? 'bg-[#E21B70] text-white'
              : 'bg-white/85 hover:bg-white text-gray-800'
          }`}
        >
          <Heart className={`w-4 h-4 ${isFavorite ? 'fill-white text-white' : 'text-[#E21B70]'}`} />
          <span>{isFavorite ? 'Favorited' : 'Favorite'}</span>
        </button>
      </div>

      {/* Menu Categories & Items */}
      <div className="space-y-8">
        {/* Most Popular */}
        {popularItems.length > 0 && (
          <section>
            <div className="flex items-center gap-2 mb-4 pb-2 border-b border-gray-100">
              <Flame className="w-5 h-5 text-amber-500" />
              <h3 className="text-lg sm:text-xl font-black text-gray-900">
                Most Popular Dishes
              </h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
              {popularItems.map(renderItemCard)}
            </div>
          </section>
        )}

        {/* Full Menu */}
        <section>
          <div className="flex items-center gap-2 mb-4 pb-2 border-b border-gray-100">
            <h3 className="text-lg sm:text-xl font-black text-gray-900">
              Full Restaurant Menu
            </h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
            {(otherItems.length > 0 ? otherItems : restaurant.menu).map(renderItemCard)}
          </div>
        </section>
      </div>
    </div>
  );
};
