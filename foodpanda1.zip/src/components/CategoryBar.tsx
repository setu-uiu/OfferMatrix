import React from 'react';

interface CategoryBarProps {
  categories: string[];
  activeCategory: string;
  onSelectCategory: (cat: string) => void;
}

const CATEGORY_ICONS: Record<string, string> = {
  All: '🍽️',
  Biriyani: '🍚',
  Bengali: '🥘',
  Kebab: '🍢',
  Burger: '🍔',
  Pizza: '🍕',
  Chinese: '🥡',
  Thai: '🍲',
  Sushi: '🍣',
  Dessert: '🍰',
  Healthy: '🥗',
  Paratha: '🫓',
  Mughlai: '👑',
  'Street Food': '🌮',
};

export const CategoryBar: React.FC<CategoryBarProps> = ({
  categories,
  activeCategory,
  onSelectCategory,
}) => {
  return (
    <div className="my-3 sm:my-5">
      <div className="flex items-center gap-2 sm:gap-2.5 overflow-x-auto pb-2 scrollbar-none select-none">
        {categories.map((cat) => {
          const isActive = cat === activeCategory;
          const icon = CATEGORY_ICONS[cat] || '🍴';
          return (
            <button
              key={cat}
              type="button"
              onClick={() => onSelectCategory(cat)}
              className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs sm:text-sm font-bold whitespace-nowrap transition cursor-pointer border ${
                isActive
                  ? 'bg-[#E21B70] text-white border-[#E21B70] shadow-md shadow-pink-200 scale-[1.02]'
                  : 'bg-white text-gray-700 hover:text-[#E21B70] border-gray-200 hover:border-pink-200'
              }`}
            >
              <span className="text-base">{icon}</span>
              <span>{cat}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
