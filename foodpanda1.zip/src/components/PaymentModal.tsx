import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Loader2, CheckCircle2, ShieldCheck } from 'lucide-react';
import { PaymentMethod } from '../types';

interface PaymentModalProps {
  isOpen: boolean;
  status: 'processing' | 'success';
  paymentMethod: PaymentMethod;
  amount: number;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  status,
  paymentMethod,
  amount,
}) => {
  useEffect(() => {
    if (isOpen && status === 'success') {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#E21B70', '#FF3B70', '#FFB800', '#00BA88'],
      });
    }
  }, [isOpen, status]);

  if (!isOpen) return null;

  const methodNames: Record<PaymentMethod, string> = {
    bkash: 'bKash Merchant Gateway',
    nagad: 'Nagad Direct Pay',
    card: 'Visa/Mastercard 3D Secure',
    cod: 'Cash on Delivery Escrow',
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4"
      id="payment-modal"
    >
      <div className="bg-white rounded-2xl w-full max-w-sm p-7 text-center shadow-2xl animate-in zoom-in-95 duration-200">
        {status === 'processing' ? (
          <div className="py-4 space-y-4">
            <div className="relative inline-block">
              <Loader2 className="w-14 h-14 text-[#E21B70] animate-spin mx-auto" />
              <div className="absolute inset-0 flex items-center justify-center text-[10px] font-black text-pink-500">
                🔒
              </div>
            </div>
            <div>
              <h3 className="text-lg font-black text-gray-900 mb-1">
                Processing Secure Payment
              </h3>
              <p className="text-xs text-gray-500">
                Connecting to {methodNames[paymentMethod]} for ৳{amount}...
              </p>
            </div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-700 text-[11px] font-bold rounded-full">
              <ShieldCheck className="w-3.5 h-3.5" /> 256-bit Bank Grade Security
            </div>
          </div>
        ) : (
          <div className="py-4 space-y-4 animate-in fade-in duration-300">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <div>
              <h3 className="text-xl font-black text-gray-900 mb-1">
                Payment Successful!
              </h3>
              <p className="text-xs text-gray-500">
                Paid ৳{amount} via {methodNames[paymentMethod]}. Your food is being ordered!
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
