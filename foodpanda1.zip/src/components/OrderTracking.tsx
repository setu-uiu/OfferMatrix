import React, { useState, useEffect } from 'react';
import { Order } from '../types';
import {
  CheckCircle2,
  Receipt,
  Flame,
  Bike,
  Home,
  Phone,
  Clock,
  MapPin,
  Bell,
  ArrowRight,
  ShieldCheck
} from 'lucide-react';

interface OrderTrackingProps {
  order: Order | null;
  onBrowseMore: () => void;
  onRequestPushNotifications: () => void;
  hasNotificationPermission: boolean;
}

const STAGES = [
  { id: 'placed', label: 'Order Placed', icon: Receipt },
  { id: 'preparing', label: 'Kitchen Preparing', icon: Flame },
  { id: 'on-the-way', label: 'On the Way', icon: Bike },
  { id: 'delivered', label: 'Delivered', icon: Home },
];

export const OrderTracking: React.FC<OrderTrackingProps> = ({
  order,
  onBrowseMore,
  onRequestPushNotifications,
  hasNotificationPermission,
}) => {
  const [timeLeft, setTimeLeft] = useState('25:00');

  useEffect(() => {
    if (!order) return;

    const timer = setInterval(() => {
      const now = new Date().getTime();
      const target = new Date(order.estDelivery).getTime();
      const diff = target - now;

      if (diff <= 0 || order.status === 'delivered') {
        setTimeLeft('00:00');
        clearInterval(timer);
      } else {
        const mins = Math.floor(diff / 60000);
        const secs = Math.floor((diff % 60000) / 1000);
        setTimeLeft(`${mins}:${secs < 10 ? '0' : ''}${secs}`);
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [order]);

  if (!order) {
    return (
      <div className="py-16 text-center max-w-md mx-auto">
        <div className="w-20 h-20 rounded-full bg-pink-50 text-[#E21B70] flex items-center justify-center mx-auto mb-4">
          <Clock className="w-10 h-10" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">No Active Orders</h2>
        <p className="text-xs sm:text-sm text-gray-500 mb-6">
          When you place a food order, you can track its live preparation and delivery here in real-time.
        </p>
        <button
          type="button"
          onClick={onBrowseMore}
          className="bg-[#E21B70] hover:bg-[#c4155f] text-white font-bold px-6 py-3 rounded-xl transition shadow-md shadow-pink-200 inline-flex items-center gap-2 cursor-pointer"
        >
          <span>Browse Restaurants</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    );
  }

  // Calculate current stage index
  const stageMap: Record<string, number> = {
    placed: 0,
    confirmed: 0,
    preparing: 1,
    'on-the-way': 2,
    delivered: 3,
    cancelled: 0,
  };
  const currentStageIdx = stageMap[order.status] ?? 0;
  const progressPercent =
    order.status === 'delivered' ? 100 : (currentStageIdx / (STAGES.length - 1)) * 100;

  const statusSubtitles: Record<string, string> = {
    placed: 'Your order is verified and forwarded to the restaurant kitchen',
    confirmed: 'Restaurant has accepted and verified your order',
    preparing: 'Chef is cooking your fresh ingredients with care',
    'on-the-way': `${order.rider?.name || 'Rider'} has collected your bag and is riding to you`,
    delivered: 'Food has arrived! Thank you for ordering with foodpanda',
    cancelled: 'This order has been cancelled',
  };

  return (
    <div className="py-4 max-w-3xl mx-auto">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#E21B70] to-[#FF477E] rounded-2xl p-6 sm:p-8 text-white shadow-lg mb-6 relative overflow-hidden">
        <div className="relative z-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-xs font-black uppercase tracking-wider mb-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            <span>Live Order Tracking</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight mb-1">
            Order #{order.id}
          </h1>
          <p className="text-xs sm:text-sm text-white/90">
            {statusSubtitles[order.status] || 'Order in progress'}
          </p>
        </div>
      </div>

      {/* Real-time Push Notification Opt-in Prompt */}
      {!hasNotificationPermission && (
        <div className="mb-6 p-4 bg-pink-50 border border-pink-200 rounded-xl flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#E21B70] text-white flex items-center justify-center shrink-0">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-gray-900">Enable Order Push Notifications</div>
              <div className="text-[11px] text-gray-600">
                Receive live status alerts when the rider arrives and kitchen starts
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={onRequestPushNotifications}
            className="px-3 py-1.5 bg-[#E21B70] text-white text-xs font-bold rounded-lg hover:bg-[#c4155f] transition shrink-0 cursor-pointer"
          >
            Allow
          </button>
        </div>
      )}

      {/* Real-Time Progress Bar Component */}
      <div className="bg-white rounded-2xl p-6 sm:p-7 border border-gray-100 shadow-xs mb-6">
        <h3 className="text-sm font-black text-gray-400 uppercase tracking-wider mb-6">
          Delivery Progress
        </h3>

        {/* Bar & Steps */}
        <div className="relative mb-8">
          {/* Background Track Line */}
          <div className="absolute top-5 left-6 right-6 h-1 bg-gray-100 rounded-full z-0"></div>
          {/* Animated Fill Track Line */}
          <div
            className="absolute top-5 left-6 h-1 bg-[#E21B70] rounded-full transition-all duration-700 ease-out z-0"
            style={{ width: `${Math.max(4, progressPercent)}%` }}
          ></div>

          {/* Step Icons */}
          <div className="relative z-10 flex justify-between items-start">
            {STAGES.map((st, i) => {
              const Icon = st.icon;
              const isDone = i < currentStageIdx || order.status === 'delivered';
              const isCurrent = i === currentStageIdx && order.status !== 'delivered';

              return (
                <div key={st.id} className="flex flex-col items-center text-center max-w-[70px] sm:max-w-[90px]">
                  <div
                    className={`w-10 h-10 sm:w-11 sm:h-11 rounded-full flex items-center justify-center transition duration-300 border-2 ${
                      isDone
                        ? 'bg-[#E21B70] text-white border-[#E21B70] shadow-md shadow-pink-200'
                        : isCurrent
                        ? 'bg-white text-[#E21B70] border-[#E21B70] ring-4 ring-pink-100 animate-pulse'
                        : 'bg-white text-gray-400 border-gray-200'
                    }`}
                  >
                    {isDone ? <CheckCircle2 className="w-5 h-5" /> : <Icon className="w-4 h-4 sm:w-5 sm:h-5" />}
                  </div>
                  <span
                    className={`text-[10px] sm:text-xs font-bold mt-2.5 ${
                      isDone || isCurrent ? 'text-gray-900' : 'text-gray-400'
                    }`}
                  >
                    {st.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Timers Breakdown */}
        <div className="grid grid-cols-2 gap-3 pt-4 border-t border-gray-100">
          <div className="p-3 bg-pink-50/60 rounded-xl text-center">
            <div className="text-[11px] font-bold text-gray-500 uppercase tracking-wider mb-1">
              Estimated Delivery
            </div>
            <div className="text-base sm:text-lg font-black text-[#E21B70]">
              {new Date(order.estDelivery).toLocaleTimeString('en-US', {
                hour: 'numeric',
                minute: '2-digit',
                hour12: true,
              })}
            </div>
          </div>

          <div className="p-3 bg-pink-50/60 rounded-xl text-center">
            <div className="text-[11px] font-bold text-gray-500 uppercase tracking-wider mb-1">
              Countdown
            </div>
            <div className="text-base sm:text-lg font-black text-gray-900 font-mono">
              {order.status === 'delivered' ? 'Arrived!' : timeLeft}
            </div>
          </div>
        </div>
      </div>

      {/* Assigned Delivery Hero / Rider Details */}
      {order.rider && (
        <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs mb-6 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-lg">
              🛵
            </div>
            <div>
              <div className="text-[10px] font-extrabold text-[#E21B70] uppercase tracking-wider">
                Assigned Delivery Hero
              </div>
              <h4 className="font-black text-base text-gray-900">{order.rider.name}</h4>
              <p className="text-xs text-gray-500">{order.rider.phone}</p>
            </div>
          </div>

          <a
            href={`tel:${order.rider.phone}`}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition shadow-sm cursor-pointer"
          >
            <Phone className="w-3.5 h-3.5" /> Call Rider
          </a>
        </div>
      )}

      {/* Order Summary & Delivery Address */}
      <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-xs space-y-4 mb-6">
        <h4 className="font-bold text-sm sm:text-base text-gray-900 flex items-center gap-2">
          <MapPin className="w-4 h-4 text-[#E21B70]" /> Delivery Address
        </h4>
        <p className="text-xs sm:text-sm text-gray-700 bg-gray-50 p-3 rounded-xl">
          {order.address}
        </p>

        <h4 className="font-bold text-sm sm:text-base text-gray-900 pt-2 border-t border-gray-100 flex items-center gap-2">
          <Receipt className="w-4 h-4 text-[#E21B70]" /> Ordered Items
        </h4>
        <div className="divide-y divide-gray-100 text-xs text-gray-700">
          {order.items.map((it) => (
            <div key={it.itemId} className="py-2.5 flex justify-between">
              <span>
                {it.name} <span className="text-gray-400">× {it.qty}</span>
              </span>
              <span className="font-bold text-gray-900">৳{it.price * it.qty}</span>
            </div>
          ))}
        </div>

        <div className="pt-3 border-t border-gray-100 flex justify-between items-baseline text-sm">
          <div className="flex items-center gap-1 text-xs text-emerald-600 font-bold">
            <ShieldCheck className="w-3.5 h-3.5" /> Paid via {order.paymentMethod.toUpperCase()} (
            {order.transactionId})
          </div>
          <div className="font-black text-base sm:text-lg text-[#E21B70]">
            Total: ৳{order.totals.total}
          </div>
        </div>
      </div>

      <div className="text-center">
        <button
          type="button"
          onClick={onBrowseMore}
          className="px-6 py-3 bg-gray-900 hover:bg-black text-white font-bold text-xs sm:text-sm rounded-xl transition inline-flex items-center gap-2 cursor-pointer"
        >
          <span>Order from Another Restaurant</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
