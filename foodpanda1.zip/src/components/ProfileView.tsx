import React from 'react';
import { User, Order } from '../types';
import {
  User as UserIcon,
  Mail,
  Phone,
  Clock,
  Heart,
  MapPin,
  LogOut,
  ShieldCheck,
  ChevronRight,
  Receipt
} from 'lucide-react';

interface ProfileViewProps {
  user: User | null;
  orders: Order[];
  onNavigate: (view: string) => void;
  onLogout: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  user,
  orders,
  onNavigate,
  onLogout,
}) => {
  return (
    <div className="py-4 max-w-3xl mx-auto space-y-6">
      {/* Profile Card Header */}
      <div className="bg-white rounded-2xl p-6 sm:p-7 border border-gray-100 shadow-xs flex flex-col sm:flex-row items-center sm:items-start gap-5 text-center sm:text-left">
        <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-[#E21B70] to-[#FF477E] text-white flex items-center justify-center text-3xl font-black shadow-lg shadow-pink-200 shrink-0">
          {user?.name ? user.name.charAt(0).toUpperCase() : <UserIcon className="w-10 h-10" />}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mb-1">
            <h1 className="text-xl sm:text-2xl font-black text-gray-900">{user?.name}</h1>
            <span
              className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full uppercase tracking-wider ${
                user?.role === 'admin'
                  ? 'bg-gray-900 text-white'
                  : 'bg-pink-100 text-[#E21B70]'
              }`}
            >
              {user?.role === 'admin' ? 'Super Admin' : 'foodpanda Member'}
            </span>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 text-xs text-gray-500 mt-2">
            <span className="flex items-center justify-center sm:justify-start gap-1.5">
              <Mail className="w-3.5 h-3.5 text-gray-400" /> {user?.email}
            </span>
            <span className="flex items-center justify-center sm:justify-start gap-1.5">
              <Phone className="w-3.5 h-3.5 text-gray-400" /> {user?.phone || '01XXXXXXXXX'}
            </span>
          </div>
        </div>
      </div>

      {/* Quick Navigation Menu */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-xs divide-y divide-gray-100 overflow-hidden text-xs sm:text-sm">
        <div
          onClick={() => onNavigate('favorites')}
          className="p-4 flex items-center justify-between hover:bg-pink-50/50 transition cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-pink-100 text-[#E21B70] flex items-center justify-center">
              <Heart className="w-4 h-4" />
            </div>
            <span className="font-bold text-gray-900">Saved Favorite Restaurants</span>
          </div>
          <ChevronRight className="w-4 h-4 text-gray-400" />
        </div>

        <div
          onClick={() => onNavigate('tracking')}
          className="p-4 flex items-center justify-between hover:bg-pink-50/50 transition cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-600 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
            <span className="font-bold text-gray-900">Active Order Live Tracker</span>
          </div>
          <ChevronRight className="w-4 h-4 text-gray-400" />
        </div>

        <div
          onClick={onLogout}
          className="p-4 flex items-center justify-between hover:bg-rose-50/50 transition cursor-pointer text-rose-600"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-rose-100 text-rose-600 flex items-center justify-center">
              <LogOut className="w-4 h-4" />
            </div>
            <span className="font-bold">Log Out Account</span>
          </div>
          <ChevronRight className="w-4 h-4 text-rose-300" />
        </div>
      </div>

      {/* Order History */}
      <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-xs space-y-4">
        <div className="flex items-center gap-2">
          <Receipt className="w-5 h-5 text-[#E21B70]" />
          <h3 className="font-extrabold text-base sm:text-lg text-gray-900">
            Order History ({orders.length})
          </h3>
        </div>

        <div className="divide-y divide-gray-100">
          {orders.length > 0 ? (
            orders.map((o) => {
              const dateStr = new Date(o.placedAt).toLocaleDateString('en-GB', {
                day: 'numeric',
                month: 'short',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              });
              const isDelivered = o.status === 'delivered';

              return (
                <div key={o.id} className="py-3.5 flex items-center justify-between gap-4 text-xs">
                  <div>
                    <div className="font-extrabold text-sm text-gray-900 mb-0.5">
                      #{o.id} · <span className="text-[#E21B70]">৳{o.totals.total}</span>
                    </div>
                    <div className="text-gray-400 text-[11px] mb-1">{dateStr}</div>
                    <div className="text-gray-600 text-[11px] line-clamp-1">
                      {o.items.map((it) => `${it.name} (${it.qty})`).join(', ')}
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span
                      className={`inline-block px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                        isDelivered
                          ? 'bg-emerald-50 text-emerald-700'
                          : o.status === 'cancelled'
                          ? 'bg-rose-50 text-rose-700'
                          : 'bg-amber-50 text-amber-700'
                      }`}
                    >
                      {o.status}
                    </span>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="py-8 text-center text-xs text-gray-400">
              No orders yet. Start your food journey today!
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
