import React, { useState, useEffect } from 'react';
import { Tag, Sparkles, Bike, Gift } from 'lucide-react';

interface PromoSliderProps {
  onApplyCode?: (code: string) => void;
}

const SLIDES = [
  {
    id: 1,
    title: '৫০% ছাড় প্রথম অর্ডারে!',
    subtitle: 'Use code to get up to ৳200 off on your first food order',
    code: 'WELCOME50',
    icon: Gift,
    bg: 'from-[#E21B70] via-[#FF3B70] to-[#FF6B35]',
    emoji: '🍔',
  },
  {
    id: 2,
    title: 'Free Delivery All Weekend!',
    subtitle: 'Zero delivery charges on all your favourite restaurants',
    code: 'FREEWEEKEND',
    icon: Bike,
    bg: 'from-[#5856D6] via-[#7B61FF] to-[#9B51E0]',
    emoji: '🛵',
  },
  {
    id: 3,
    title: 'Buy 1 Get 1 Free Feast!',
    subtitle: 'Delicious BOGO meals on biryani, pizza and burger combos',
    code: 'BOGOFOOD',
    icon: Sparkles,
    bg: 'from-[#FF6B35] via-[#FF8C42] to-[#FFA62B]',
    emoji: '🍕',
  },
];

export const PromoSlider: React.FC<PromoSliderProps> = ({ onApplyCode }) => {
  const [activeIdx, setActiveIdx] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveIdx((prev) => (prev + 1) % SLIDES.length);
    }, 4500);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="relative rounded-2xl overflow-hidden shadow-md my-4 sm:my-6" id="promo-carousel">
      <div
        className="flex transition-transform duration-500 ease-out"
        style={{ transform: `translateX(-${activeIdx * 100}%)` }}
      >
        {SLIDES.map((slide) => {
          const Icon = slide.icon;
          return (
            <div
              key={slide.id}
              className={`min-w-full p-6 sm:p-9 bg-gradient-to-r ${slide.bg} text-white relative flex items-center justify-between overflow-hidden`}
            >
              <div className="z-10 max-w-lg">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-bold mb-3">
                  <Icon className="w-3.5 h-3.5" /> Special Offer
                </div>
                <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight mb-2">
                  {slide.title}
                </h2>
                <p className="text-xs sm:text-sm text-white/90 mb-4 max-w-md">
                  {slide.subtitle}
                </p>
                <div className="inline-flex items-center gap-2 bg-white/25 hover:bg-white/35 backdrop-blur-md border border-white/40 px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-black tracking-wider transition cursor-pointer"
                  onClick={() => onApplyCode && onApplyCode(slide.code)}
                  title="Click to copy voucher code"
                >
                  <Tag className="w-3.5 h-3.5" />
                  <span>CODE: {slide.code}</span>
                </div>
              </div>

              {/* Decorative giant emoji */}
              <div className="text-7xl sm:text-9xl opacity-25 select-none pointer-events-none transform translate-x-4 sm:translate-x-0">
                {slide.emoji}
              </div>
            </div>
          );
        })}
      </div>

      {/* Navigation Indicators */}
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-1.5 z-20">
        {SLIDES.map((_, i) => (
          <button
            key={i}
            onClick={() => setActiveIdx(i)}
            className={`h-2 rounded-full transition-all duration-300 cursor-pointer ${
              activeIdx === i ? 'w-6 bg-white' : 'w-2 bg-white/40'
            }`}
            aria-label={`Slide ${i + 1}`}
          />
        ))}
      </div>
    </div>
  );
};
