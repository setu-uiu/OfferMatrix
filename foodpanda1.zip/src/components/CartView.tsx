import React, { useState } from 'react';
import { CartItem, PaymentMethod, PromoRule, OrderTotals } from '../types';
import {
  ShoppingBag,
  Trash2,
  Plus,
  Minus,
  MapPin,
  FileText,
  CreditCard,
  ShieldCheck,
  Tag,
  Receipt,
  Smartphone,
  Banknote,
  ArrowRight
} from 'lucide-react';

interface CartViewProps {
  cart: CartItem[];
  userAddress: string;
  promoRules: Record<string, PromoRule>;
  onUpdateQty: (itemId: number, delta: number) => void;
  onRemoveItem: (itemId: number) => void;
  onCheckout: (data: {
    address: string;
    notes: string;
    paymentMethod: PaymentMethod;
    cardDetails?: { cardNumber: string; expiry: string; cvv: string };
    promoDiscount: number;
    totals: OrderTotals;
  }) => void;
  onBrowse: () => void;
}

export const CartView: React.FC<CartViewProps> = ({
  cart,
  userAddress,
  promoRules,
  onUpdateQty,
  onRemoveItem,
  onCheckout,
  onBrowse,
}) => {
  const [address, setAddress] = useState(userAddress || 'House 42, Road 9/A, Dhanmondi, Dhaka');
  const [notes, setNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('bkash');
  const [promoInput, setPromoInput] = useState('');
  const [promoDiscount, setPromoDiscount] = useState(0);
  const [appliedPromo, setAppliedPromo] = useState<string | null>(null);
  const [promoMessage, setPromoMessage] = useState<{ text: string; isError: boolean } | null>(null);

  // Card details
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');

  // Computations
  const subtotal = cart.reduce((acc, c) => acc + c.price * c.qty, 0);
  const deliveryFee = cart.length > 0 ? Math.max(...cart.map((c) => c.fee)) : 0;
  const vat = Math.round(subtotal * 0.05); // 5% VAT
  const total = Math.max(0, subtotal + deliveryFee + vat - promoDiscount);

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    const code = promoInput.trim().toUpperCase();
    if (!code) return;

    if (promoRules[code]) {
      const rule = promoRules[code];
      let discount = 0;
      if (rule.pct) {
        discount = Math.min(Math.round((subtotal * rule.pct) / 100), rule.max || 9999);
      } else if (rule.flat) {
        discount = Math.min(rule.flat, rule.max || rule.flat, subtotal);
      } else if (rule.freeDelivery) {
        discount = deliveryFee;
      }
      setPromoDiscount(discount);
      setAppliedPromo(code);
      setPromoMessage({ text: `Voucher "${code}" applied! You save ৳${discount}`, isError: false });
    } else {
      setPromoDiscount(0);
      setAppliedPromo(null);
      setPromoMessage({ text: 'Invalid promo code. Please try WELCOME50', isError: true });
    }
  };

  const handleFormatCard = (val: string) => {
    const raw = val.replace(/\D/g, '').substring(0, 16);
    const formatted = raw.replace(/(\d{4})/g, '$1 ').trim();
    setCardNumber(formatted);
  };

  const handleFormatExpiry = (val: string) => {
    let raw = val.replace(/\D/g, '').substring(0, 4);
    if (raw.length >= 3) {
      raw = `${raw.substring(0, 2)}/${raw.substring(2)}`;
    }
    setCardExpiry(raw);
  };

  const handleSubmitOrder = () => {
    if (!address.trim()) {
      alert('Please provide a delivery address');
      return;
    }
    if (cart.length === 0) {
      alert('Your cart is empty');
      return;
    }

    if (paymentMethod === 'card') {
      if (cardNumber.replace(/\s/g, '').length < 15) {
        alert('Please enter a valid 16-digit card number');
        return;
      }
      if (!/^\d{2}\/\d{2}$/.test(cardExpiry)) {
        alert('Please enter a valid expiry date (MM/YY)');
        return;
      }
      if (cardCvv.length < 3) {
        alert('Please enter a valid 3-digit CVV');
        return;
      }
    }

    onCheckout({
      address: address.trim(),
      notes: notes.trim(),
      paymentMethod,
      cardDetails:
        paymentMethod === 'card'
          ? { cardNumber: cardNumber.replace(/\s/g, ''), expiry: cardExpiry, cvv: cardCvv }
          : undefined,
      promoDiscount,
      totals: {
        sub: subtotal,
        fee: deliveryFee,
        vat,
        disc: promoDiscount,
        total,
      },
    });
  };

  if (cart.length === 0) {
    return (
      <div className="py-16 text-center max-w-md mx-auto">
        <div className="w-20 h-20 rounded-full bg-pink-50 text-[#E21B70] flex items-center justify-center mx-auto mb-4">
          <ShoppingBag className="w-10 h-10" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Your Cart is Empty</h2>
        <p className="text-xs sm:text-sm text-gray-500 mb-6">
          Explore top-rated restaurants and order something delicious today!
        </p>
        <button
          type="button"
          onClick={onBrowse}
          className="bg-[#E21B70] hover:bg-[#c4155f] text-white font-bold px-6 py-3 rounded-xl transition shadow-md shadow-pink-200 inline-flex items-center gap-2 cursor-pointer"
        >
          <span>Find Restaurants</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    );
  }

  return (
    <div className="py-4">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-pink-100 flex items-center justify-center text-[#E21B70]">
          <ShoppingBag className="w-5 h-5" />
        </div>
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-gray-900">Your Basket</h1>
          <p className="text-xs text-gray-500">Review your order and select secure payment</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Cart Items */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs">
            <h3 className="font-bold text-base text-gray-900 mb-3 flex items-center gap-2">
              <span>Order Items</span>
              <span className="text-xs bg-pink-100 text-[#E21B70] font-bold px-2 py-0.5 rounded-full">
                {cart.reduce((s, c) => s + c.qty, 0)}
              </span>
            </h3>

            <div className="divide-y divide-gray-100">
              {cart.map((item) => (
                <div key={item.itemId} className="py-3 flex items-center justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <h4 className="font-bold text-sm text-gray-900 truncate">{item.name}</h4>
                    <p className="text-xs text-gray-500 truncate">{item.restName}</p>
                    <div className="text-xs font-extrabold text-[#E21B70] mt-0.5">
                      ৳{item.price} each
                    </div>
                  </div>

                  {/* Qty and Remove */}
                  <div className="flex items-center gap-3 shrink-0">
                    <div className="flex items-center bg-gray-100 rounded-lg overflow-hidden">
                      <button
                        type="button"
                        onClick={() => onUpdateQty(item.itemId, -1)}
                        className="w-7 h-7 flex items-center justify-center text-gray-600 hover:bg-gray-200 transition cursor-pointer"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="w-7 text-center text-xs font-bold text-gray-900">
                        {item.qty}
                      </span>
                      <button
                        type="button"
                        onClick={() => onUpdateQty(item.itemId, 1)}
                        className="w-7 h-7 flex items-center justify-center text-gray-600 hover:bg-gray-200 transition cursor-pointer"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    <span className="w-16 text-right text-sm font-extrabold text-gray-900">
                      ৳{item.price * item.qty}
                    </span>

                    <button
                      type="button"
                      onClick={() => onRemoveItem(item.itemId)}
                      className="text-gray-400 hover:text-rose-500 transition p-1 cursor-pointer"
                      title="Remove item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Delivery Details */}
          <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs space-y-4">
            <h3 className="font-bold text-base text-gray-900 flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[#E21B70]" /> Delivery Information
            </h3>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">
                Delivery Address <span className="text-[#E21B70]">*</span>
              </label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="House, road, landmark and area"
                className="w-full h-11 px-3.5 border border-gray-200 rounded-xl text-sm focus:border-[#E21B70] focus:ring-2 focus:ring-pink-100 focus:outline-none transition"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1 flex items-center gap-1">
                <FileText className="w-3.5 h-3.5 text-gray-400" /> Instructions for Rider (optional)
              </label>
              <textarea
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g. Please leave at door, don't ring bell, floor #4"
                className="w-full p-3 border border-gray-200 rounded-xl text-sm focus:border-[#E21B70] focus:ring-2 focus:ring-pink-100 focus:outline-none transition resize-none"
              />
            </div>
          </div>
        </div>

        {/* Right Column: Payment & Order Summary */}
        <div className="lg:col-span-5 space-y-4">
          {/* Secure Payment Gateway Selector */}
          <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs">
            <h3 className="font-bold text-base text-gray-900 mb-3 flex items-center justify-between">
              <span className="flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-[#E21B70]" /> Payment Method
              </span>
              <span className="inline-flex items-center gap-1 text-[10px] text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded-full">
                <ShieldCheck className="w-3 h-3" /> SSL 256-bit Encrypted
              </span>
            </h3>

            <div className="grid grid-cols-2 gap-2.5 mb-3">
              {/* bKash */}
              <button
                type="button"
                onClick={() => setPaymentMethod('bkash')}
                className={`p-3 rounded-xl border text-left flex items-center gap-2.5 transition cursor-pointer ${
                  paymentMethod === 'bkash'
                    ? 'border-[#E21B70] bg-pink-50 text-[#E21B70] shadow-xs'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="w-7 h-7 rounded-lg bg-[#E21B70] text-white flex items-center justify-center font-black text-xs shrink-0">
                  b
                </div>
                <div>
                  <div className="text-xs font-extrabold text-gray-900">bKash</div>
                  <div className="text-[10px] text-gray-500">Direct Pay</div>
                </div>
              </button>

              {/* Nagad */}
              <button
                type="button"
                onClick={() => setPaymentMethod('nagad')}
                className={`p-3 rounded-xl border text-left flex items-center gap-2.5 transition cursor-pointer ${
                  paymentMethod === 'nagad'
                    ? 'border-orange-500 bg-orange-50 text-orange-600 shadow-xs'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="w-7 h-7 rounded-lg bg-orange-500 text-white flex items-center justify-center font-black text-xs shrink-0">
                  N
                </div>
                <div>
                  <div className="text-xs font-extrabold text-gray-900">Nagad</div>
                  <div className="text-[10px] text-gray-500">Fast Gateway</div>
                </div>
              </button>

              {/* Card */}
              <button
                type="button"
                onClick={() => setPaymentMethod('card')}
                className={`p-3 rounded-xl border text-left flex items-center gap-2.5 transition cursor-pointer ${
                  paymentMethod === 'card'
                    ? 'border-[#E21B70] bg-pink-50 text-[#E21B70] shadow-xs'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="w-7 h-7 rounded-lg bg-slate-800 text-white flex items-center justify-center text-xs shrink-0">
                  <CreditCard className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-extrabold text-gray-900">Debit / Credit</div>
                  <div className="text-[10px] text-gray-500">Visa / MC</div>
                </div>
              </button>

              {/* COD */}
              <button
                type="button"
                onClick={() => setPaymentMethod('cod')}
                className={`p-3 rounded-xl border text-left flex items-center gap-2.5 transition cursor-pointer ${
                  paymentMethod === 'cod'
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-700 shadow-xs'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center text-xs shrink-0">
                  <Banknote className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-extrabold text-gray-900">Cash on Del.</div>
                  <div className="text-[10px] text-gray-500">Pay on arrival</div>
                </div>
              </button>
            </div>

            {/* Credit Card Input Form (revealed when Card selected) */}
            {paymentMethod === 'card' && (
              <div className="p-3.5 bg-gray-50 rounded-xl border border-gray-200 space-y-2.5 animate-in fade-in duration-200 text-xs">
                <div>
                  <label className="block font-bold text-gray-700 mb-1">Card Number</label>
                  <input
                    type="text"
                    value={cardNumber}
                    onChange={(e) => handleFormatCard(e.target.value)}
                    placeholder="4111 2222 3333 4444"
                    maxLength={19}
                    className="w-full h-9 px-3 bg-white border border-gray-200 rounded-lg font-mono focus:border-[#E21B70] focus:outline-none"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block font-bold text-gray-700 mb-1">Expiry (MM/YY)</label>
                    <input
                      type="text"
                      value={cardExpiry}
                      onChange={(e) => handleFormatExpiry(e.target.value)}
                      placeholder="12/28"
                      maxLength={5}
                      className="w-full h-9 px-3 bg-white border border-gray-200 rounded-lg font-mono focus:border-[#E21B70] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-gray-700 mb-1">CVV</label>
                    <input
                      type="password"
                      value={cardCvv}
                      onChange={(e) => setCardCvv(e.target.value.replace(/\D/g, '').substring(0, 4))}
                      placeholder="123"
                      maxLength={4}
                      className="w-full h-9 px-3 bg-white border border-gray-200 rounded-lg font-mono focus:border-[#E21B70] focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Promo Code Form */}
          <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs">
            <h3 className="font-bold text-base text-gray-900 mb-2 flex items-center gap-2">
              <Tag className="w-4 h-4 text-[#E21B70]" /> Apply Promo Voucher
            </h3>
            <form onSubmit={handleApplyPromo} className="flex gap-2">
              <input
                type="text"
                value={promoInput}
                onChange={(e) => setPromoInput(e.target.value)}
                placeholder="Enter promo code (e.g. WELCOME50)"
                className="flex-1 h-10 px-3 border border-gray-200 rounded-xl text-xs uppercase font-bold focus:border-[#E21B70] focus:ring-2 focus:ring-pink-100 focus:outline-none transition"
              />
              <button
                type="submit"
                className="px-4 h-10 bg-gray-900 hover:bg-black text-white text-xs font-bold rounded-xl transition cursor-pointer"
              >
                Apply
              </button>
            </form>
            {promoMessage && (
              <p className={`text-xs mt-2 font-bold ${promoMessage.isError ? 'text-rose-600' : 'text-emerald-600'}`}>
                {promoMessage.text}
              </p>
            )}
          </div>

          {/* Receipt Breakdown & Submit */}
          <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs space-y-3">
            <h3 className="font-bold text-base text-gray-900 flex items-center gap-2">
              <Receipt className="w-4 h-4 text-[#E21B70]" /> Order Summary
            </h3>

            <div className="space-y-2 text-xs text-gray-600">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="font-bold text-gray-900">৳{subtotal}</span>
              </div>
              <div className="flex justify-between">
                <span>Delivery Fee</span>
                <span className="font-bold text-gray-900">৳{deliveryFee}</span>
              </div>
              <div className="flex justify-between">
                <span>VAT (5%)</span>
                <span className="font-bold text-gray-900">৳{vat}</span>
              </div>
              {promoDiscount > 0 && (
                <div className="flex justify-between text-emerald-600 font-bold">
                  <span>Voucher Discount</span>
                  <span>-৳{promoDiscount}</span>
                </div>
              )}
              <div className="pt-2 border-t border-gray-100 flex justify-between items-baseline text-base">
                <span className="font-bold text-gray-900">Total to Pay</span>
                <span className="font-black text-xl text-[#E21B70]">৳{total}</span>
              </div>
            </div>

            <button
              type="button"
              onClick={handleSubmitOrder}
              className="w-full h-13 bg-[#E21B70] hover:bg-[#c4155f] text-white font-extrabold text-base rounded-xl transition shadow-lg shadow-pink-200 flex items-center justify-center gap-2 cursor-pointer mt-2"
              id="place-order-btn"
            >
              <ShieldCheck className="w-5 h-5" />
              <span>Place Order (৳{total})</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
