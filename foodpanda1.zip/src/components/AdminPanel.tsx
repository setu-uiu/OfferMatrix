import React, { useState } from 'react';
import { Restaurant, Rider, PromoRule, Order, OrderStatus } from '../types';
import {
  Store,
  Utensils,
  Tag,
  Bike,
  ClipboardList,
  Plus,
  Trash2,
  Search,
  CheckCircle2,
  ArrowRight
} from 'lucide-react';

interface AdminPanelProps {
  restaurants: Restaurant[];
  riders: Rider[];
  promos: Record<string, PromoRule>;
  orders: Order[];
  onAddRestaurant: (data: Partial<Restaurant>) => void;
  onDeleteRestaurant: (id: number) => void;
  onAddMenuItem: (restId: number, item: { name: string; desc: string; price: number; popular?: boolean }) => void;
  onDeleteMenuItem: (restId: number, itemId: number) => void;
  onAddPromo: (promo: { code: string; type: 'pct' | 'flat'; value: number; max?: number }) => void;
  onDeletePromo: (code: string) => void;
  onAddRider: (rider: { name: string; phone: string; status?: string }) => void;
  onUpdateRiderStatus: (id: number, status: 'online' | 'offline' | 'on-delivery') => void;
  onDeleteRider: (id: number) => void;
  onUpdateOrderStatus: (orderId: string, status: OrderStatus) => void;
  onSwitchToCustomer: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  restaurants,
  riders,
  promos,
  orders,
  onAddRestaurant,
  onDeleteRestaurant,
  onAddMenuItem,
  onDeleteMenuItem,
  onAddPromo,
  onDeletePromo,
  onAddRider,
  onUpdateRiderStatus,
  onDeleteRider,
  onUpdateOrderStatus,
  onSwitchToCustomer,
}) => {
  const [selectedRestId, setSelectedRestId] = useState<number>(restaurants[0]?.id || 1);
  const [adminSearch, setAdminSearch] = useState('');

  // Form states: New Restaurant
  const [newRestName, setNewRestName] = useState('');
  const [newRestCuisine, setNewRestCuisine] = useState('');
  const [newRestCats, setNewRestCats] = useState('Biriyani, Bengali');
  const [newRestFee, setNewRestFee] = useState(35);
  const [newRestTime, setNewRestTime] = useState('20-30 min');
  const [newRestImg, setNewRestImg] = useState('');

  // Form states: New Food Item
  const [foodName, setFoodName] = useState('');
  const [foodDesc, setFoodDesc] = useState('');
  const [foodPrice, setFoodPrice] = useState('');
  const [foodPopular, setFoodPopular] = useState(false);

  // Form states: New Promo
  const [promoCode, setPromoCode] = useState('');
  const [promoType, setPromoType] = useState<'pct' | 'flat'>('pct');
  const [promoVal, setPromoVal] = useState('');
  const [promoMax, setPromoMax] = useState('');

  // Form states: New Rider
  const [riderName, setRiderName] = useState('');
  const [riderPhone, setRiderPhone] = useState('');
  const [riderStatus, setRiderStatus] = useState<'online' | 'offline' | 'on-delivery'>('online');

  const selectedRest = restaurants.find((r) => r.id === selectedRestId) || restaurants[0];

  // Stats
  const totalFoodCount = restaurants.reduce((sum, r) => sum + r.menu.length, 0);
  const promoKeys = Object.keys(promos);

  // Filter lists based on admin global search
  const q = adminSearch.toLowerCase().trim();
  const filteredOrders = q
    ? orders.filter(
        (o) =>
          o.id.toLowerCase().includes(q) ||
          o.customerName.toLowerCase().includes(q) ||
          o.status.toLowerCase().includes(q)
      )
    : orders;

  const filteredRestaurants = q
    ? restaurants.filter(
        (r) => r.name.toLowerCase().includes(q) || r.cuisine.toLowerCase().includes(q)
      )
    : restaurants;

  const filteredRiders = q
    ? riders.filter(
        (r) => r.name.toLowerCase().includes(q) || r.phone.toLowerCase().includes(q)
      )
    : riders;

  return (
    <div className="py-4 space-y-6">
      {/* Admin Hero Banner */}
      <div className="bg-gradient-to-r from-gray-900 via-slate-800 to-[#E21B70] rounded-2xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-pink-500/30 border border-pink-400/30 backdrop-blur-md rounded-full text-xs font-black uppercase tracking-wider text-pink-300 mb-2">
            Super Admin Control Center
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight mb-1">
            foodpanda Platform Administration
          </h1>
          <p className="text-xs sm:text-sm text-gray-300 max-w-xl">
            Real-time management for restaurants, digital menus, promo vouchers, live customer orders and delivery riders.
          </p>
        </div>

        <button
          type="button"
          onClick={onSwitchToCustomer}
          className="bg-white hover:bg-gray-100 text-gray-900 font-extrabold px-5 py-2.5 rounded-xl transition text-xs sm:text-sm flex items-center gap-2 shrink-0 cursor-pointer shadow-md"
        >
          <span>Customer View</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
        <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-pink-100 text-[#E21B70] flex items-center justify-center shrink-0">
            <Store className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xl font-black text-gray-900">{restaurants.length}</div>
            <div className="text-[11px] text-gray-500 font-medium">Restaurants</div>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center shrink-0">
            <Utensils className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xl font-black text-gray-900">{totalFoodCount}</div>
            <div className="text-[11px] text-gray-500 font-medium">Menu Items</div>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-600 flex items-center justify-center shrink-0">
            <Tag className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xl font-black text-gray-900">{promoKeys.length}</div>
            <div className="text-[11px] text-gray-500 font-medium">Active Promos</div>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center shrink-0">
            <Bike className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xl font-black text-gray-900">{riders.length}</div>
            <div className="text-[11px] text-gray-500 font-medium">Delivery Riders</div>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-xs flex items-center gap-3 col-span-2 sm:col-span-1">
          <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center shrink-0">
            <ClipboardList className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xl font-black text-gray-900">{orders.length}</div>
            <div className="text-[11px] text-gray-500 font-medium">Customer Orders</div>
          </div>
        </div>
      </div>

      {/* Admin Global Search */}
      <div className="relative">
        <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={adminSearch}
          onChange={(e) => setAdminSearch(e.target.value)}
          placeholder="Filter orders, restaurants, dishes, riders, promo codes..."
          className="w-full h-11 pl-10 pr-4 bg-white border border-gray-200 rounded-xl text-xs sm:text-sm focus:border-[#E21B70] focus:ring-2 focus:ring-pink-100 focus:outline-none transition shadow-xs"
        />
      </div>

      {/* Live Orders Management */}
      <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <ClipboardList className="w-5 h-5 text-[#E21B70]" />
            <h3 className="font-extrabold text-base sm:text-lg text-gray-900">
              Live Customer Orders ({filteredOrders.length})
            </h3>
          </div>
          <span className="text-[11px] text-emerald-700 bg-emerald-50 font-bold px-2.5 py-1 rounded-full flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" /> Real-time WebSockets Sync
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-gray-50 text-gray-500 font-bold uppercase tracking-wider text-[10px]">
              <tr>
                <th className="p-3">Order ID</th>
                <th className="p-3">Customer</th>
                <th className="p-3">Items</th>
                <th className="p-3">Total</th>
                <th className="p-3">Payment</th>
                <th className="p-3">Live Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredOrders.length > 0 ? (
                filteredOrders.map((o) => (
                  <tr key={o.id} className="hover:bg-pink-50/40 transition">
                    <td className="p-3 font-extrabold text-gray-900">{o.id}</td>
                    <td className="p-3">
                      <div className="font-bold text-gray-900">{o.customerName}</div>
                      <div className="text-gray-400 text-[11px]">{o.customerPhone}</div>
                    </td>
                    <td className="p-3 text-gray-700 max-w-xs truncate">
                      {o.items.map((it) => `${it.name} (${it.qty})`).join(', ')}
                    </td>
                    <td className="p-3 font-extrabold text-[#E21B70]">৳{o.totals.total}</td>
                    <td className="p-3 uppercase font-bold text-[11px] text-gray-600">
                      {o.paymentMethod}
                    </td>
                    <td className="p-3">
                      <select
                        value={o.status}
                        onChange={(e) => onUpdateOrderStatus(o.id, e.target.value as OrderStatus)}
                        className="bg-white border border-gray-200 rounded-lg px-2.5 py-1 text-xs font-bold text-gray-800 focus:border-[#E21B70] focus:outline-none cursor-pointer"
                      >
                        <option value="placed">Placed</option>
                        <option value="confirmed">Confirmed</option>
                        <option value="preparing">Preparing</option>
                        <option value="on-the-way">On the way</option>
                        <option value="delivered">Delivered</option>
                        <option value="cancelled">Cancelled</option>
                      </select>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="p-6 text-center text-gray-400">
                    No orders matching search
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Two Column Grid: Food Item Management & Promos */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Food Item Management */}
        <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs space-y-4">
          <div className="flex items-center gap-2">
            <Utensils className="w-5 h-5 text-[#E21B70]" />
            <h3 className="font-extrabold text-base sm:text-lg text-gray-900">
              Food Item Management
            </h3>
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1">Select Restaurant</label>
            <select
              value={selectedRestId}
              onChange={(e) => setSelectedRestId(Number(e.target.value))}
              className="w-full h-10 px-3 border border-gray-200 rounded-xl text-xs font-bold text-gray-800 focus:border-[#E21B70] focus:outline-none"
            >
              {restaurants.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.name} ({r.menu.length} items)
                </option>
              ))}
            </select>
          </div>

          {/* Current menu items */}
          <div className="max-h-56 overflow-y-auto divide-y divide-gray-100 border border-gray-100 rounded-xl p-3">
            {selectedRest && selectedRest.menu.length > 0 ? (
              selectedRest.menu.map((m) => (
                <div key={m.id} className="py-2.5 flex items-center justify-between text-xs">
                  <div>
                    <div className="font-bold text-gray-900">
                      {m.name} {m.popular && <span className="text-amber-500">🔥</span>}
                    </div>
                    <div className="text-gray-400 text-[11px] truncate max-w-xs">{m.desc}</div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-black text-[#E21B70]">৳{m.price}</span>
                    <button
                      type="button"
                      onClick={() => onDeleteMenuItem(selectedRest.id, m.id)}
                      className="text-gray-400 hover:text-rose-500 transition p-1 cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-4 text-xs text-gray-400">No food items added yet</div>
            )}
          </div>

          {/* Add Food Item Form */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (foodName && foodPrice) {
                onAddMenuItem(selectedRestId, {
                  name: foodName.trim(),
                  desc: foodDesc.trim() || 'Cooked fresh upon order',
                  price: Number(foodPrice),
                  popular: foodPopular,
                });
                setFoodName('');
                setFoodDesc('');
                setFoodPrice('');
                setFoodPopular(false);
              }
            }}
            className="p-3.5 bg-gray-50 rounded-xl border border-gray-100 space-y-2.5 text-xs"
          >
            <div className="font-bold text-gray-800">Add Item to {selectedRest?.name}</div>
            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                value={foodName}
                onChange={(e) => setFoodName(e.target.value)}
                placeholder="Item Name (e.g. Mutton Kacchi)"
                required
                className="h-9 px-3 bg-white border border-gray-200 rounded-lg text-xs"
              />
              <input
                type="number"
                value={foodPrice}
                onChange={(e) => setFoodPrice(e.target.value)}
                placeholder="Price (৳)"
                required
                className="h-9 px-3 bg-white border border-gray-200 rounded-lg text-xs"
              />
            </div>
            <input
              type="text"
              value={foodDesc}
              onChange={(e) => setFoodDesc(e.target.value)}
              placeholder="Short description of ingredients & taste"
              className="w-full h-9 px-3 bg-white border border-gray-200 rounded-lg text-xs"
            />
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-1.5 cursor-pointer font-medium text-gray-700">
                <input
                  type="checkbox"
                  checked={foodPopular}
                  onChange={(e) => setFoodPopular(e.target.checked)}
                  className="rounded text-[#E21B70]"
                />
                Mark as Bestseller / Popular
              </label>
              <button
                type="submit"
                className="px-4 py-2 bg-[#E21B70] text-white font-bold rounded-lg text-xs hover:bg-[#c4155f] transition cursor-pointer flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" /> Add Dish
              </button>
            </div>
          </form>
        </div>

        {/* Promo Codes Management */}
        <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs space-y-4">
          <div className="flex items-center gap-2">
            <Tag className="w-5 h-5 text-[#E21B70]" />
            <h3 className="font-extrabold text-base sm:text-lg text-gray-900">
              Vouchers & Promo Codes
            </h3>
          </div>

          <div className="max-h-56 overflow-y-auto divide-y divide-gray-100 border border-gray-100 rounded-xl p-3">
            {promoKeys.map((code) => {
              const rule = promos[code];
              return (
                <div key={code} className="py-2.5 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-mono font-black text-gray-900 bg-gray-100 px-2 py-0.5 rounded-md">
                      {code}
                    </span>
                    <span className="text-gray-500 text-[11px] ml-2">
                      {rule.pct ? `${rule.pct}% OFF (Max ৳${rule.max})` : `৳${rule.flat} Flat Discount`}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => onDeletePromo(code)}
                    className="text-gray-400 hover:text-rose-500 transition p-1 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              );
            })}
          </div>

          {/* Add Promo Form */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (promoCode && promoVal) {
                onAddPromo({
                  code: promoCode.trim().toUpperCase(),
                  type: promoType,
                  value: Number(promoVal),
                  max: promoMax ? Number(promoMax) : undefined,
                });
                setPromoCode('');
                setPromoVal('');
                setPromoMax('');
              }
            }}
            className="p-3.5 bg-gray-50 rounded-xl border border-gray-100 space-y-2.5 text-xs"
          >
            <div className="font-bold text-gray-800">Create New Promo Code</div>
            <div className="grid grid-cols-3 gap-2">
              <input
                type="text"
                value={promoCode}
                onChange={(e) => setPromoCode(e.target.value)}
                placeholder="CODE (e.g. SUMMER25)"
                required
                className="h-9 px-3 bg-white border border-gray-200 rounded-lg uppercase font-bold"
              />
              <select
                value={promoType}
                onChange={(e) => setPromoType(e.target.value as 'pct' | 'flat')}
                className="h-9 px-2 bg-white border border-gray-200 rounded-lg font-bold"
              >
                <option value="pct">Percentage (%)</option>
                <option value="flat">Flat Taka (৳)</option>
              </select>
              <input
                type="number"
                value={promoVal}
                onChange={(e) => setPromoVal(e.target.value)}
                placeholder="Discount Value"
                required
                className="h-9 px-3 bg-white border border-gray-200 rounded-lg"
              />
            </div>
            <div className="flex items-center justify-between gap-2">
              <input
                type="number"
                value={promoMax}
                onChange={(e) => setPromoMax(e.target.value)}
                placeholder="Maximum Discount Cap (৳, optional)"
                className="h-9 px-3 bg-white border border-gray-200 rounded-lg flex-1"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-gray-900 text-white font-bold rounded-lg text-xs hover:bg-black transition cursor-pointer flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" /> Add Code
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Restaurant Management Section */}
      <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs space-y-4">
        <div className="flex items-center gap-2">
          <Store className="w-5 h-5 text-[#E21B70]" />
          <h3 className="font-extrabold text-base sm:text-lg text-gray-900">
            Restaurant Partners ({filteredRestaurants.length})
          </h3>
        </div>

        {/* Restaurant cards list */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {filteredRestaurants.map((r) => (
            <div
              key={r.id}
              className="p-3 border border-gray-100 rounded-xl flex items-center justify-between gap-2 bg-gray-50/60"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <img
                  src={r.img}
                  alt={r.name}
                  className="w-10 h-10 rounded-lg object-cover shrink-0"
                />
                <div className="min-w-0">
                  <div className="font-bold text-xs text-gray-900 truncate">{r.name}</div>
                  <div className="text-[10px] text-gray-400 truncate">{r.cuisine}</div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => onDeleteRestaurant(r.id)}
                className="text-gray-400 hover:text-rose-500 transition p-1.5 cursor-pointer shrink-0"
                title="Delete restaurant"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>

        {/* Add Restaurant Form */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (newRestName && newRestCuisine) {
              onAddRestaurant({
                name: newRestName.trim(),
                cuisine: newRestCuisine.trim(),
                cats: newRestCats.split(',').map((c) => c.trim()),
                fee: Number(newRestFee),
                time: newRestTime.trim(),
                img: newRestImg.trim() || undefined,
              });
              setNewRestName('');
              setNewRestCuisine('');
              setNewRestImg('');
            }
          }}
          className="p-4 bg-gray-50 rounded-xl border border-gray-100 space-y-3 text-xs"
        >
          <div className="font-bold text-gray-800">Onboard New Restaurant</div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            <input
              type="text"
              value={newRestName}
              onChange={(e) => setNewRestName(e.target.value)}
              placeholder="Restaurant Name"
              required
              className="h-9 px-3 bg-white border border-gray-200 rounded-lg"
            />
            <input
              type="text"
              value={newRestCuisine}
              onChange={(e) => setNewRestCuisine(e.target.value)}
              placeholder="Cuisine (e.g. Biriyani · Bengali)"
              required
              className="h-9 px-3 bg-white border border-gray-200 rounded-lg"
            />
            <input
              type="text"
              value={newRestCats}
              onChange={(e) => setNewRestCats(e.target.value)}
              placeholder="Categories (comma-separated)"
              className="h-9 px-3 bg-white border border-gray-200 rounded-lg"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            <input
              type="number"
              value={newRestFee}
              onChange={(e) => setNewRestFee(Number(e.target.value))}
              placeholder="Delivery Fee (৳)"
              className="h-9 px-3 bg-white border border-gray-200 rounded-lg"
            />
            <input
              type="text"
              value={newRestTime}
              onChange={(e) => setNewRestTime(e.target.value)}
              placeholder="Est. Time (e.g. 25-35 min)"
              className="h-9 px-3 bg-white border border-gray-200 rounded-lg"
            />
            <input
              type="url"
              value={newRestImg}
              onChange={(e) => setNewRestImg(e.target.value)}
              placeholder="Photo URL (optional)"
              className="h-9 px-3 bg-white border border-gray-200 rounded-lg"
            />
          </div>

          <button
            type="submit"
            className="px-5 py-2.5 bg-[#E21B70] text-white font-bold rounded-lg text-xs hover:bg-[#c4155f] transition cursor-pointer flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" /> Add Restaurant Partner
          </button>
        </form>
      </div>

      {/* Delivery Heroes / Riders Management */}
      <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs space-y-4">
        <div className="flex items-center gap-2">
          <Bike className="w-5 h-5 text-[#E21B70]" />
          <h3 className="font-extrabold text-base sm:text-lg text-gray-900">
            Delivery Fleet Management ({filteredRiders.length} Riders)
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {filteredRiders.map((rd) => (
            <div
              key={rd.id}
              className="p-3.5 border border-gray-100 rounded-xl bg-gray-50/60 flex items-center justify-between gap-3 text-xs"
            >
              <div>
                <div className="font-bold text-gray-900">{rd.name}</div>
                <div className="text-gray-400 text-[11px]">{rd.phone}</div>
                <div className="text-[10px] text-gray-500 mt-1">
                  Completed: <strong>{rd.totalDeliveries}</strong>
                </div>
              </div>

              <div className="flex flex-col items-end gap-1.5">
                <select
                  value={rd.status}
                  onChange={(e) =>
                    onUpdateRiderStatus(rd.id, e.target.value as 'online' | 'offline' | 'on-delivery')
                  }
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full border cursor-pointer ${
                    rd.status === 'online'
                      ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                      : rd.status === 'on-delivery'
                      ? 'bg-amber-50 text-amber-700 border-amber-200'
                      : 'bg-gray-100 text-gray-600 border-gray-200'
                  }`}
                >
                  <option value="online">Online</option>
                  <option value="on-delivery">On Delivery</option>
                  <option value="offline">Offline</option>
                </select>

                <button
                  type="button"
                  onClick={() => onDeleteRider(rd.id)}
                  className="text-gray-400 hover:text-rose-500 transition p-1 cursor-pointer"
                  title="Remove rider"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Add Rider Form */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (riderName && riderPhone) {
              onAddRider({
                name: riderName.trim(),
                phone: riderPhone.trim(),
                status: riderStatus,
              });
              setRiderName('');
              setRiderPhone('');
            }
          }}
          className="p-3.5 bg-gray-50 rounded-xl border border-gray-100 space-y-2.5 text-xs flex flex-wrap items-center gap-2"
        >
          <input
            type="text"
            value={riderName}
            onChange={(e) => setRiderName(e.target.value)}
            placeholder="Rider Full Name"
            required
            className="h-9 px-3 bg-white border border-gray-200 rounded-lg flex-1 min-w-[150px]"
          />
          <input
            type="text"
            value={riderPhone}
            onChange={(e) => setRiderPhone(e.target.value)}
            placeholder="Phone (+880...)"
            required
            className="h-9 px-3 bg-white border border-gray-200 rounded-lg flex-1 min-w-[150px]"
          />
          <select
            value={riderStatus}
            onChange={(e) => setRiderStatus(e.target.value as any)}
            className="h-9 px-3 bg-white border border-gray-200 rounded-lg font-bold"
          >
            <option value="online">Online</option>
            <option value="offline">Offline</option>
            <option value="on-delivery">On Delivery</option>
          </select>
          <button
            type="submit"
            className="h-9 px-4 bg-gray-900 text-white font-bold rounded-lg text-xs hover:bg-black transition cursor-pointer flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" /> Add Delivery Hero
          </button>
        </form>
      </div>
    </div>
  );
};
