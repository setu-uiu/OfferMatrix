import React, { useState } from 'react';
import { UserRole } from '../types';
import {
  User as UserIcon,
  ShieldCheck,
  Mail,
  Lock,
  Phone,
  Eye,
  EyeOff,
  ArrowRight
} from 'lucide-react';

interface AuthModalProps {
  onLogin: (email: string, password: string, role: UserRole) => Promise<void>;
  onRegister: (data: { name: string; email: string; phone: string; password: string; role: UserRole }) => Promise<void>;
}

export const AuthModal: React.FC<AuthModalProps> = ({ onLogin, onRegister }) => {
  const [role, setRole] = useState<UserRole>('customer');
  const [mode, setMode] = useState<'login' | 'register'>('login');

  const [email, setEmail] = useState('user@foodpanda.com');
  const [password, setPassword] = useState('panda123');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleRoleChange = (newRole: UserRole) => {
    setRole(newRole);
    setErrorMsg(null);
    if (newRole === 'admin') {
      setEmail('admin@foodpanda.com');
      setPassword('admin123');
      setMode('login');
    } else {
      setEmail('user@foodpanda.com');
      setPassword('panda123');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg(null);

    try {
      if (mode === 'login') {
        await onLogin(email.trim(), password, role);
      } else {
        await onRegister({
          name: name.trim() || 'Food Lover',
          email: email.trim(),
          phone: phone.trim() || '01700000000',
          password,
          role,
        });
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Authentication failed. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickAdmin = async () => {
    handleRoleChange('admin');
    setLoading(true);
    try {
      await onLogin('admin@foodpanda.com', 'admin123', 'admin');
    } catch {
      setErrorMsg('Failed quick admin login');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-white overflow-y-auto flex min-h-screen"
      id="auth-screen"
    >
      <div className="grid grid-cols-1 lg:grid-cols-12 w-full min-h-screen">
        {/* Left Side: Brand Visual Cover */}
        <div
          className={`lg:col-span-6 relative p-8 sm:p-12 flex flex-col justify-between overflow-hidden transition-colors duration-500 ${
            role === 'admin'
              ? 'bg-gradient-to-br from-gray-950 via-slate-900 to-[#E21B70]'
              : 'bg-gradient-to-br from-[#E21B70] via-[#FF3B70] to-[#FF6B35]'
          }`}
        >
          {/* Subtle food photo background overlay */}
          <div
            className="absolute inset-0 opacity-20 mix-blend-overlay bg-cover bg-center pointer-events-none"
            style={{
              backgroundImage: `url('https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=1200&q=80')`,
            }}
          ></div>

          {/* Brand Header */}
          <div className="relative z-10">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-white text-[#E21B70] flex items-center justify-center text-2xl font-black shadow-lg">
                🐼
              </div>
              <span className="text-3xl sm:text-4xl font-black tracking-tight text-white">
                foodpanda
              </span>
            </div>
          </div>

          {/* Hero Pitch */}
          <div className="relative z-10 my-12 max-w-md">
            <h1 className="text-3xl sm:text-5xl font-black text-white leading-tight mb-4 tracking-tight">
              {role === 'admin' ? (
                <>
                  Manage the <br />
                  <span className="text-pink-300">foodpanda</span> network.
                </>
              ) : (
                <>
                  Craving food? <br />
                  <span className="text-pink-100">foodpanda</span> it.
                </>
              )}
            </h1>
            <p className="text-sm sm:text-base text-white/90 leading-relaxed">
              {role === 'admin'
                ? 'Full administrative control over restaurant menus, live order status updates, delivery riders and active promo vouchers.'
                : 'Order hot Kacchi biryani, cheesy pizza, burgers, sweets and fast delivery right to your door.'}
            </p>
          </div>

          {/* Platform Trust Stats */}
          <div className="relative z-10 grid grid-cols-3 gap-4 pt-6 border-t border-white/20 text-white">
            <div>
              <div className="text-xl sm:text-2xl font-black">10,000+</div>
              <div className="text-xs text-white/80">Restaurants</div>
            </div>
            <div>
              <div className="text-xl sm:text-2xl font-black">200k+</div>
              <div className="text-xs text-white/80">Dishes</div>
            </div>
            <div>
              <div className="text-xl sm:text-2xl font-black">25 min</div>
              <div className="text-xs text-white/80">Avg. Delivery</div>
            </div>
          </div>
        </div>

        {/* Right Side: Auth Form Panel */}
        <div className="lg:col-span-6 flex items-center justify-center p-6 sm:p-12 bg-white">
          <div className="w-full max-w-md space-y-5">
            {/* Perspective / Role Switcher */}
            <div className="bg-gray-100 p-1 rounded-xl grid grid-cols-2 gap-1 text-xs font-extrabold">
              <button
                type="button"
                onClick={() => handleRoleChange('customer')}
                className={`py-2.5 rounded-lg flex items-center justify-center gap-1.5 transition cursor-pointer ${
                  role === 'customer'
                    ? 'bg-white text-[#E21B70] shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <UserIcon className="w-4 h-4" /> Customer
              </button>
              <button
                type="button"
                onClick={() => handleRoleChange('admin')}
                className={`py-2.5 rounded-lg flex items-center justify-center gap-1.5 transition cursor-pointer ${
                  role === 'admin'
                    ? 'bg-gray-900 text-white shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <ShieldCheck className="w-4 h-4" /> Admin Portal
              </button>
            </div>

            {/* Login / Register Tab Header */}
            <div>
              <h2 className="text-2xl font-black text-gray-900 mb-1">
                {mode === 'login' ? 'Welcome Back' : 'Create Account'}
              </h2>
              <p className="text-xs text-gray-500">
                {role === 'admin'
                  ? 'Access platform administration and order dispatch dashboard'
                  : 'Enter your credentials to start ordering delicious food'}
              </p>
            </div>

            {role !== 'admin' && (
              <div className="flex border-b border-gray-100 text-xs font-bold">
                <button
                  type="button"
                  onClick={() => setMode('login')}
                  className={`pb-3 border-b-2 mr-6 transition cursor-pointer ${
                    mode === 'login'
                      ? 'border-[#E21B70] text-[#E21B70]'
                      : 'border-transparent text-gray-400 hover:text-gray-700'
                  }`}
                >
                  Sign In
                </button>
                <button
                  type="button"
                  onClick={() => setMode('register')}
                  className={`pb-3 border-b-2 transition cursor-pointer ${
                    mode === 'register'
                      ? 'border-[#E21B70] text-[#E21B70]'
                      : 'border-transparent text-gray-400 hover:text-gray-700'
                  }`}
                >
                  Create New Account
                </button>
              </div>
            )}

            {errorMsg && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-600 rounded-xl text-xs font-semibold">
                {errorMsg}
              </div>
            )}

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
              {mode === 'register' && (
                <div>
                  <label className="block font-bold text-gray-700 mb-1">Full Name</label>
                  <div className="relative flex items-center">
                    <UserIcon className="w-4 h-4 text-gray-400 absolute left-3" />
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Your Full Name"
                      required
                      className="w-full h-11 pl-9 pr-3 border border-gray-200 rounded-xl text-xs sm:text-sm focus:border-[#E21B70] focus:ring-2 focus:ring-pink-100 focus:outline-none transition"
                    />
                  </div>
                </div>
              )}

              {mode === 'register' && (
                <div>
                  <label className="block font-bold text-gray-700 mb-1">Phone Number</label>
                  <div className="relative flex items-center">
                    <Phone className="w-4 h-4 text-gray-400 absolute left-3" />
                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="017XXXXXXXX"
                      required
                      className="w-full h-11 pl-9 pr-3 border border-gray-200 rounded-xl text-xs sm:text-sm focus:border-[#E21B70] focus:ring-2 focus:ring-pink-100 focus:outline-none transition"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="block font-bold text-gray-700 mb-1">Email or Username</label>
                <div className="relative flex items-center">
                  <Mail className="w-4 h-4 text-gray-400 absolute left-3" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@email.com"
                    required
                    className="w-full h-11 pl-9 pr-3 border border-gray-200 rounded-xl text-xs sm:text-sm focus:border-[#E21B70] focus:ring-2 focus:ring-pink-100 focus:outline-none transition"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-gray-700 mb-1">Password</label>
                <div className="relative flex items-center">
                  <Lock className="w-4 h-4 text-gray-400 absolute left-3" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your password"
                    required
                    className="w-full h-11 pl-9 pr-10 border border-gray-200 rounded-xl text-xs sm:text-sm focus:border-[#E21B70] focus:ring-2 focus:ring-pink-100 focus:outline-none transition"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 text-gray-400 hover:text-gray-600 transition cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className={`w-full h-12 rounded-xl text-white font-black text-sm flex items-center justify-center gap-2 transition shadow-md cursor-pointer mt-2 ${
                  role === 'admin'
                    ? 'bg-gray-900 hover:bg-black'
                    : 'bg-[#E21B70] hover:bg-[#c4155f] shadow-pink-200'
                }`}
              >
                <span>{loading ? 'Authenticating...' : mode === 'login' ? 'Sign In to foodpanda' : 'Create Account'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>

            {/* Demo Accounts Box */}
            <div className="p-3.5 bg-pink-50/60 rounded-xl border border-pink-100 text-[11px] text-gray-600 space-y-1">
              <div className="font-black text-[#E21B70] uppercase tracking-wider">Quick Demo Login:</div>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                <span>Customer: <b>user@foodpanda.com</b> / <b>panda123</b></span>
                <button
                  type="button"
                  onClick={() => {
                    handleRoleChange('customer');
                    setEmail('user@foodpanda.com');
                    setPassword('panda123');
                  }}
                  className="text-[#E21B70] underline font-bold cursor-pointer"
                >
                  Fill Customer
                </button>
              </div>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 pt-1 border-t border-pink-100">
                <span>Admin: <b>admin@foodpanda.com</b> / <b>admin123</b></span>
                <button
                  type="button"
                  onClick={() => {
                    handleRoleChange('admin');
                    setEmail('admin@foodpanda.com');
                    setPassword('admin123');
                  }}
                  className="text-gray-900 underline font-bold cursor-pointer"
                >
                  Fill Admin
                </button>
              </div>
            </div>

            {/* Quick 1-click Admin Entry */}
            <button
              type="button"
              onClick={handleQuickAdmin}
              className="w-full py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-800 text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Direct 1-Click Admin Access</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
