import React, { useState } from 'react';
import { X, MapPin, Crosshair } from 'lucide-react';

interface LocationModalProps {
  isOpen: boolean;
  currentLocation: string;
  onClose: () => void;
  onSaveLocation: (loc: string) => void;
}

export const LocationModal: React.FC<LocationModalProps> = ({
  isOpen,
  currentLocation,
  onClose,
  onSaveLocation,
}) => {
  const [inputVal, setInputVal] = useState(currentLocation);

  if (!isOpen) return null;

  const handleLocateMe = () => {
    const popularLocations = [
      'Bashundhara R/A, Block C, Dhaka',
      'Road 27, Dhanmondi, Dhaka',
      'Gulshan 2, Madani Avenue, Dhaka',
      'Sector 7, Uttara, Dhaka',
      'Banani 11, Dhaka',
    ];
    const picked = popularLocations[Math.floor(Math.random() * popularLocations.length)];
    setInputVal(picked);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputVal.trim()) {
      onSaveLocation(inputVal.trim());
      onClose();
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4"
      id="location-modal-overlay"
    >
      <div className="bg-white rounded-2xl w-full max-w-xl overflow-hidden shadow-2xl relative animate-in fade-in zoom-in-95 duration-200">
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute right-4 top-4 w-9 h-9 rounded-full bg-gray-100 hover:bg-gray-200 text-gray-600 flex items-center justify-center transition cursor-pointer z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Content */}
        <div className="p-6 sm:p-7">
          <h2 className="text-xl font-bold text-gray-900 mb-1">Select Delivery Location</h2>
          <p className="text-xs sm:text-sm text-gray-500 mb-5">
            Choose your address to see restaurants delivering to your area
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="relative flex items-center">
              <MapPin className="w-5 h-5 text-[#E21B70] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={inputVal}
                onChange={(e) => setInputVal(e.target.value)}
                placeholder="Enter street, house number or area"
                className="w-full h-12 pl-11 pr-28 border border-gray-200 rounded-xl text-sm focus:border-[#E21B70] focus:ring-2 focus:ring-pink-100 focus:outline-none transition"
                id="location-modal-input"
              />
              <button
                type="button"
                onClick={handleLocateMe}
                className="absolute right-2 top-1/2 -translate-y-1/2 bg-pink-50 hover:bg-pink-100 text-[#E21B70] text-xs font-bold px-2.5 py-1.5 rounded-lg flex items-center gap-1 transition cursor-pointer"
              >
                <Crosshair className="w-3.5 h-3.5" /> Locate
              </button>
            </div>

            {/* Simulated Map View with Roads and Pulse Pin */}
            <div className="relative h-48 sm:h-56 bg-slate-100 rounded-xl overflow-hidden border border-gray-200">
              {/* Map grid lines / roads */}
              <div className="absolute inset-0 opacity-40 bg-[radial-gradient(#94a3b8_1px,transparent_1px)] [background-size:16px_16px]"></div>
              
              {/* Simulated streets */}
              <div className="absolute w-[120%] h-4 bg-white/90 top-[35%] -left-[10%] rotate-[-6deg] shadow-xs flex items-center pl-8 text-[9px] font-bold text-slate-400">
                Mirpur Road · Dhaka
              </div>
              <div className="absolute w-[120%] h-3.5 bg-white/90 top-[68%] -left-[10%] rotate-[10deg] shadow-xs flex items-center pl-16 text-[9px] font-bold text-slate-400">
                Satmasjid Road
              </div>
              <div className="absolute h-[120%] w-4 bg-white/90 left-[55%] -top-[10%] rotate-[12deg] shadow-xs flex items-center pt-8 text-[9px] font-bold text-slate-400 [writing-mode:vertical-lr]">
                Dhanmondi Lake
              </div>

              {/* Center Map Pin */}
              <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center">
                <div className="relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-pink-400 opacity-60"></span>
                  <div className="w-10 h-10 rounded-full bg-[#E21B70] text-white flex items-center justify-center shadow-lg border-2 border-white">
                    <MapPin className="w-5 h-5 fill-white" />
                  </div>
                </div>
                <div className="bg-gray-900 text-white text-[11px] font-semibold px-2.5 py-1 rounded-full shadow-md mt-1.5 whitespace-nowrap">
                  Deliver Here
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="w-full h-12 bg-[#E21B70] hover:bg-[#c4155f] text-white font-bold text-sm sm:text-base rounded-xl transition shadow-md shadow-pink-200 cursor-pointer"
              id="location-modal-submit"
            >
              Confirm Delivery Address
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
