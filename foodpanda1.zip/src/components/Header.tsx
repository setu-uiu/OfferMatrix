import React, { useState, useRef, useEffect } from 'react';
import { User, Restaurant } from '../types';
import {
  MapPin,
  Search,
  Heart,
  ShoppingCart,
  ShieldCheck,
  User as UserIcon,
  ChevronDown,
  Store,
  Utensils
} from 'lucide-react';

interface HeaderProps {
  user: User | null;
  appMode: 'customer' | 'admin';
  cartCount: number;
  favCount: number;
  userLocation: string;
  restaurants: Restaurant[];
  onNavigate: (view: string) => void;
  onToggleAppMode: () => void;
  onOpenLocationModal: () => void;
  onSelectRestaurant: (id: number) => void;
}

export const Header: React.FC<HeaderProps> = ({
  user,
  appMode,
  cartCount,
  favCount,
  userLocation,
  restaurants,
  onNavigate,
  onToggleAppMode,
  onOpenLocationModal,
  onSelectRestaurant
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  // Close search results on outside click
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setIsSearchOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const searchResults: { type: 'restaurant' | 'food'; rest: Restaurant; item?: any }[] = [];
  if (searchQuery.trim().length > 0) {
    const q = searchQuery.toLowerCase().trim();
    restaurants.forEach((r) => {
      if (r.name.toLowerCase().includes(q) || r.cuisine.toLowerCase().includes(q)) {
        searchResults.push({ type: 'restaurant', rest: r });
      }
      r.menu.forEach((m) => {
        if (m.name.toLowerCase().includes(q)) {
          searchResults.push({ type: 'food', rest: r, item: m });
        }
      });
    });
  }

  return (
    <header className="sticky top-0 z-40 bg-white shadow-xs border-b border-gray-100 font-sans">
      {/* Top partner bar */}
      <div className="bg-[#E21B70] text-white py-1.5 px-4 text-xs sm:text-sm font-medium flex items-center justify-between sm:justify-center gap-3">
        <span>Want to become a foodpanda partner? Grow your restaurant with us</span>
        <button
          type="button"
          onClick={() => alert('Partner Portal: restaurant.foodpanda.com (Demo)')}
          className="bg-white text-[#E21B70] px-2.5 py-0.5 rounded text-xs font-bold hover:bg-gray-100 transition"
        >
          Become a Partner
        </button>
      </div>

      {/* Main navigation header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 sm:h-20 flex items-center justify-between gap-3 sm:gap-6">
        {/* Brand Logo */}
        <div
          onClick={() => onNavigate(appMode === 'admin' ? 'admin' : 'home')}
          className="cursor-pointer flex items-center gap-2 select-none shrink-0"
          id="foodpanda-logo"
        >
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-[#E21B70] to-[#FF477E] flex items-center justify-center text-white shadow-md shadow-pink-200">
            <span className="text-xl leading-none">🐼</span>
          </div>
          <span className="text-2xl sm:text-3xl font-black tracking-tight text-[#E21B70]">
            foodpanda
          </span>
        </div>

        {/* Location deliver-to picker */}
        <button
          type="button"
          onClick={onOpenLocationModal}
          className="hidden md:flex items-center gap-2 py-1.5 px-3 rounded-lg hover:bg-pink-50/60 border border-transparent hover:border-pink-100 transition text-left cursor-pointer shrink-0"
          id="location-picker-btn"
        >
          <MapPin className="w-5 h-5 text-[#E21B70] shrink-0" />
          <div className="max-w-[150px] lg:max-w-[200px]">
            <div className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Deliver to</div>
            <div className="text-xs lg:text-sm font-semibold text-gray-800 truncate">{userLocation}</div>
          </div>
          <ChevronDown className="w-3.5 h-3.5 text-gray-400 ml-1" />
        </button>

        {/* Live Search Bar */}
        <div ref={searchContainerRef} className="flex-1 max-w-md relative hidden sm:block">
          <div className="relative">
            <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setIsSearchOpen(true);
              }}
              onFocus={() => setIsSearchOpen(true)}
              placeholder="Search restaurants or dishes..."
              className="w-full h-10 pl-10 pr-4 bg-gray-100/80 border border-transparent rounded-full text-sm text-gray-800 placeholder-gray-400 focus:bg-white focus:border-[#E21B70] focus:ring-2 focus:ring-pink-100 focus:outline-none transition"
              id="header-search-input"
            />
          </div>

          {/* Autocomplete Dropdown */}
          {isSearchOpen && searchQuery.trim().length > 0 && (
            <div className="absolute left-0 right-0 top-full mt-2 bg-white rounded-xl shadow-xl border border-gray-100 overflow-hidden z-50 max-h-80 overflow-y-auto">
              {searchResults.length > 0 ? (
                searchResults.slice(0, 8).map((res, i) => (
                  <div
                    key={i}
                    onClick={() => {
                      onSelectRestaurant(res.rest.id);
                      setIsSearchOpen(false);
                      setSearchQuery('');
                    }}
                    className="flex items-center gap-3 p-3 hover:bg-pink-50/70 border-b border-gray-50 last:border-0 cursor-pointer transition"
                  >
                    <div className="w-8 h-8 rounded-lg bg-pink-100 flex items-center justify-center text-[#E21B70] shrink-0">
                      {res.type === 'restaurant' ? <Store className="w-4 h-4" /> : <Utensils className="w-4 h-4" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-xs sm:text-sm font-semibold text-gray-800 truncate">
                        {res.type === 'restaurant' ? res.rest.name : res.item?.name}
                      </div>
                      <div className="text-[11px] text-gray-500 truncate">
                        {res.type === 'restaurant' ? res.rest.cuisine : `${res.rest.name} · ৳${res.item?.price}`}
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-4 text-center text-xs text-gray-400">
                  No matching restaurants or dishes found
                </div>
              )}
            </div>
          )}
        </div>

        {/* Header Right Actions */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Perspective switcher (Customer / Admin) */}
          <button
            type="button"
            onClick={onToggleAppMode}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition border cursor-pointer ${
              appMode === 'admin'
                ? 'bg-gray-900 text-white border-gray-900 shadow-sm'
                : 'bg-white text-gray-700 hover:text-[#E21B70] border-gray-200 hover:border-pink-200'
            }`}
            title="Toggle between Customer food ordering and Admin platform management"
            id="mode-toggle-btn"
          >
            <ShieldCheck className={`w-3.5 h-3.5 ${appMode === 'admin' ? 'text-pink-400' : 'text-gray-500'}`} />
            <span className="hidden sm:inline">{appMode === 'admin' ? 'Admin Mode' : 'Customer Mode'}</span>
          </button>

          {/* Favorites */}
          <button
            type="button"
            onClick={() => onNavigate('favorites')}
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-gray-100/80 hover:bg-pink-50 text-gray-600 hover:text-[#E21B70] flex items-center justify-center transition relative cursor-pointer"
            title="Favorites"
            id="fav-header-btn"
          >
            <Heart className="w-4 h-4 sm:w-5 sm:h-5" />
            {favCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 bg-[#E21B70] text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center border-2 border-white">
                {favCount}
              </span>
            )}
          </button>

          {/* Cart */}
          <button
            type="button"
            onClick={() => onNavigate('cart')}
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-gray-100/80 hover:bg-pink-50 text-gray-600 hover:text-[#E21B70] flex items-center justify-center transition relative cursor-pointer"
            title="Shopping Cart"
            id="cart-header-btn"
          >
            <ShoppingCart className="w-4 h-4 sm:w-5 sm:h-5" />
            {cartCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 bg-[#E21B70] text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center border-2 border-white animate-pulse">
                {cartCount}
              </span>
            )}
          </button>

          {/* User Profile */}
          <button
            type="button"
            onClick={() => onNavigate('profile')}
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-[#E21B70] text-white font-bold text-xs sm:text-sm flex items-center justify-center hover:opacity-90 shadow-sm cursor-pointer ml-1"
            title={user ? `${user.name} (${user.role})` : 'Profile'}
            id="profile-header-btn"
          >
            {user?.name ? user.name.charAt(0).toUpperCase() : <UserIcon className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </header>
  );
};
