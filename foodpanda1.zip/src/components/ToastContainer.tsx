import React from 'react';
import { ToastMessage } from '../types';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

interface ToastContainerProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export const ToastContainer: React.FC<ToastContainerProps> = ({ toasts, onDismiss }) => {
  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-20 right-4 z-50 flex flex-col gap-2 pointer-events-none max-w-sm w-full">
      {toasts.map((t) => {
        const type = t.type || 'success';
        return (
          <div
            key={t.id}
            className={`pointer-events-auto flex items-center justify-between p-3.5 rounded-xl shadow-lg border backdrop-blur-md text-xs font-semibold animate-in slide-in-from-top-2 duration-300 ${
              type === 'success'
                ? 'bg-emerald-600 text-white border-emerald-500'
                : type === 'error'
                ? 'bg-rose-600 text-white border-rose-500'
                : 'bg-gray-900 text-white border-gray-800'
            }`}
          >
            <div className="flex items-center gap-2.5 min-w-0 pr-2">
              {type === 'success' && <CheckCircle2 className="w-4 h-4 shrink-0" />}
              {type === 'error' && <AlertCircle className="w-4 h-4 shrink-0" />}
              {type === 'info' && <Info className="w-4 h-4 shrink-0" />}
              <span className="truncate">{t.message}</span>
            </div>
            <button
              type="button"
              onClick={() => onDismiss(t.id)}
              className="text-white/80 hover:text-white p-0.5 cursor-pointer shrink-0"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
