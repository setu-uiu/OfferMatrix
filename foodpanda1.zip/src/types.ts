export type UserRole = 'customer' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
}

export interface MenuItem {
  id: number;
  name: string;
  desc: string;
  price: number;
  popular?: boolean;
}

export interface Restaurant {
  id: number;
  name: string;
  img: string;
  rating: number;
  time: string;
  fee: number;
  cats: string[];
  cuisine: string;
  promo?: string;
  menu: MenuItem[];
}

export interface CartItem {
  itemId: number;
  restId: number;
  restName: string;
  name: string;
  price: number;
  qty: number;
  fee: number;
}

export interface PromoRule {
  code: string;
  pct?: number;
  flat?: number;
  freeDelivery?: boolean;
  max?: number;
}

export type RiderStatus = 'online' | 'offline' | 'on-delivery';

export interface Rider {
  id: number;
  name: string;
  phone: string;
  status: RiderStatus;
  totalDeliveries: number;
}

export type OrderStatus = 'placed' | 'confirmed' | 'preparing' | 'on-the-way' | 'delivered' | 'cancelled';

export interface OrderTotals {
  sub: number;
  fee: number;
  vat: number;
  disc: number;
  total: number;
}

export type PaymentMethod = 'bkash' | 'nagad' | 'card' | 'cod';

export interface Order {
  id: string;
  userId: string;
  customerName: string;
  customerPhone: string;
  items: CartItem[];
  totals: OrderTotals;
  address: string;
  notes?: string;
  paymentMethod: PaymentMethod;
  paymentStatus: 'paid' | 'pending';
  transactionId?: string;
  placedAt: string;
  estDelivery: string;
  status: OrderStatus;
  rider?: {
    id: number;
    name: string;
    phone: string;
  };
}

export interface ToastMessage {
  id: string;
  message: string;
  type?: 'success' | 'error' | 'info';
}

export interface LiveNotification {
  id: string;
  title: string;
  body: string;
  orderId?: string;
  timestamp: string;
}
