import { Order, Restaurant, Rider, PromoRule, User, CartItem, PaymentMethod, LiveNotification } from '../types';

// API client
export const api = {
  async login(email: string, password?: string, role: 'customer' | 'admin' = 'customer'): Promise<{ user: User; token: string }> {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, role })
    });
    if (!res.ok) throw new Error('Login failed');
    return res.json();
  },

  async register(data: { name: string; email: string; phone: string; password?: string; role: 'customer' | 'admin' }): Promise<{ user: User; token: string }> {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) throw new Error('Registration failed');
    return res.json();
  },

  async getRestaurants(): Promise<Restaurant[]> {
    const res = await fetch('/api/restaurants');
    if (!res.ok) throw new Error('Failed to fetch restaurants');
    return res.json();
  },

  async addRestaurant(data: Partial<Restaurant>): Promise<Restaurant> {
    const res = await fetch('/api/restaurants', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) throw new Error('Failed to create restaurant');
    return res.json();
  },

  async deleteRestaurant(id: number): Promise<{ success: boolean }> {
    const res = await fetch(`/api/restaurants/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Failed to delete restaurant');
    return res.json();
  },

  async addMenuItem(restId: number, item: { name: string; desc: string; price: number; popular?: boolean }) {
    const res = await fetch(`/api/restaurants/${restId}/menu`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(item)
    });
    if (!res.ok) throw new Error('Failed to add menu item');
    return res.json();
  },

  async deleteMenuItem(restId: number, itemId: number) {
    const res = await fetch(`/api/restaurants/${restId}/menu/${itemId}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Failed to delete menu item');
    return res.json();
  },

  async getPromos(): Promise<Record<string, PromoRule>> {
    const res = await fetch('/api/promos');
    if (!res.ok) throw new Error('Failed to fetch promos');
    return res.json();
  },

  async addPromo(promo: { code: string; type: 'pct' | 'flat'; value: number; max?: number }) {
    const res = await fetch('/api/promos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(promo)
    });
    if (!res.ok) throw new Error('Failed to add promo');
    return res.json();
  },

  async deletePromo(code: string) {
    const res = await fetch(`/api/promos/${code}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Failed to delete promo');
    return res.json();
  },

  async getRiders(): Promise<Rider[]> {
    const res = await fetch('/api/riders');
    if (!res.ok) throw new Error('Failed to fetch riders');
    return res.json();
  },

  async addRider(rider: { name: string; phone: string; status?: string }) {
    const res = await fetch('/api/riders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(rider)
    });
    if (!res.ok) throw new Error('Failed to add rider');
    return res.json();
  },

  async updateRider(id: number, data: Partial<Rider>) {
    const res = await fetch(`/api/riders/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) throw new Error('Failed to update rider');
    return res.json();
  },

  async deleteRider(id: number) {
    const res = await fetch(`/api/riders/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Failed to delete rider');
    return res.json();
  },

  async getOrders(userId?: string): Promise<Order[]> {
    const url = userId ? `/api/orders?userId=${encodeURIComponent(userId)}` : '/api/orders';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Failed to fetch orders');
    return res.json();
  },

  async processPayment(data: {
    paymentMethod: PaymentMethod;
    amount: number;
    cardDetails?: { cardNumber: string; expiry: string; cvv: string };
    mobileNumber?: string;
  }) {
    const res = await fetch('/api/payments/process', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Payment gateway failed');
    }
    return res.json();
  },

  async createOrder(data: {
    userId: string;
    customerName: string;
    customerPhone: string;
    items: CartItem[];
    totals: { sub: number; fee: number; vat: number; disc: number; total: number };
    address: string;
    notes?: string;
    paymentMethod: PaymentMethod;
    transactionId?: string;
  }): Promise<Order> {
    const res = await fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) throw new Error('Failed to create order');
    return res.json();
  },

  async updateOrderStatus(id: string, status: string): Promise<{ success: boolean; order: Order; notification: LiveNotification }> {
    const res = await fetch(`/api/orders/${id}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status })
    });
    if (!res.ok) throw new Error('Failed to update status');
    return res.json();
  }
};

// WebSocket Real-time subscriber
export type WebSocketEvent =
  | { type: 'CONNECTED'; message: string }
  | { type: 'ORDER_CREATED'; order: Order; notification: LiveNotification }
  | { type: 'ORDER_STATUS_UPDATED'; order: Order; notification: LiveNotification }
  | { type: 'RESTAURANTS_UPDATED'; count: number }
  | { type: 'MENU_UPDATED'; restId: number; itemId: number }
  | { type: 'PROMOS_UPDATED' }
  | { type: 'RIDERS_UPDATED'; rider?: Rider; deletedId?: number };

export function connectWebSocket(onEvent: (event: WebSocketEvent) => void): () => void {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const wsUrl = `${protocol}//${window.location.host}`;
  let ws: WebSocket | null = null;
  let isClosed = false;
  let reconnectTimer: any = null;

  function connect() {
    try {
      ws = new WebSocket(wsUrl);

      ws.onopen = () => {
        // Send keepalive ping every 30s
        const pingInterval = setInterval(() => {
          if (ws?.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({ type: 'PING' }));
          } else {
            clearInterval(pingInterval);
          }
        }, 30000);
      };

      ws.onmessage = (e) => {
        try {
          const data = JSON.parse(e.data);
          onEvent(data);
        } catch {
          // ignore
        }
      };

      ws.onclose = () => {
        if (!isClosed) {
          reconnectTimer = setTimeout(connect, 3000);
        }
      };

      ws.onerror = () => {
        ws?.close();
      };
    } catch {
      if (!isClosed) {
        reconnectTimer = setTimeout(connect, 3000);
      }
    }
  }

  connect();

  return () => {
    isClosed = true;
    if (reconnectTimer) clearTimeout(reconnectTimer);
    ws?.close();
  };
}
