import React, { useState, useEffect } from 'react';
import {
  User,
  Restaurant,
  CartItem,
  Order,
  PromoRule,
  Rider,
  ToastMessage,
  UserRole,
  OrderStatus,
  PaymentMethod
} from './types';
import { api, connectWebSocket, WebSocketEvent } from './services/api';
import { Header } from './components/Header';
import { LocationModal } from './components/LocationModal';
import { PromoSlider } from './components/PromoSlider';
import { CategoryBar } from './components/CategoryBar';
import { RestaurantCard } from './components/RestaurantCard';
import { RestaurantDetail } from './components/RestaurantDetail';
import { CartView } from './components/CartView';
import { PaymentModal } from './components/PaymentModal';
import { OrderTracking } from './components/OrderTracking';
import { AdminPanel } from './components/AdminPanel';
import { ProfileView } from './components/ProfileView';
import { AuthModal } from './components/AuthModal';
import { ToastContainer } from './components/ToastContainer';
import {
  Home,
  Heart,
  ShoppingCart,
  Clock,
  User as UserIcon,
  Crosshair,
  ArrowRight
} from 'lucide-react';

const CATEGORIES = [
  'All',
  'Biriyani',
  'Bengali',
  'Kebab',
  'Burger',
  'Pizza',
  'Chinese',
  'Thai',
  'Sushi',
  'Dessert',
  'Healthy',
  'Paratha',
  'Mughlai',
  'Street Food'
];

export default function App() {
  // Session & Auth state
  const [user, setUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem('fpd_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [appMode, setAppMode] = useState<'customer' | 'admin'>(() => {
    return (localStorage.getItem('fpd_mode') as 'customer' | 'admin') || 'customer';
  });

  const [currentView, setCurrentView] = useState<string>('home');
  const [userLocation, setUserLocation] = useState('Dhanmondi, Dhaka');
  const [isLocationModalOpen, setIsLocationModalOpen] = useState(false);

  // Entities
  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);
  const [selectedRestId, setSelectedRestId] = useState<number | null>(null);
  const [activeCategory, setActiveCategory] = useState('All');
  const [promos, setPromos] = useState<Record<string, PromoRule>>({});
  const [riders, setRiders] = useState<Rider[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [activeOrder, setActiveOrder] = useState<Order | null>(null);

  // Cart & Favorites
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('fpd_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [favorites, setFavorites] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem('fpd_favs');
      return saved ? JSON.parse(saved) : [1, 2];
    } catch {
      return [1, 2];
    }
  });

  // Toasts & Notifications
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [hasNotificationPermission, setHasNotificationPermission] = useState(false);

  // Payment Modal State
  const [paymentModalState, setPaymentModalState] = useState<{
    isOpen: boolean;
    status: 'processing' | 'success';
    method: PaymentMethod;
    amount: number;
  }>({
    isOpen: false,
    status: 'processing',
    method: 'bkash',
    amount: 0,
  });

  // Helper toast dispatcher
  const addToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = 'toast-' + Date.now() + '-' + Math.random();
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3800);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Sync state to localStorage
  useEffect(() => {
    if (user) {
      localStorage.setItem('fpd_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('fpd_user');
    }
  }, [user]);

  useEffect(() => {
    localStorage.setItem('fpd_mode', appMode);
  }, [appMode]);

  useEffect(() => {
    localStorage.setItem('fpd_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('fpd_favs', JSON.stringify(favorites));
  }, [favorites]);

  // Check Notification API permission
  useEffect(() => {
    if ('Notification' in window) {
      setHasNotificationPermission(Notification.permission === 'granted');
    }
  }, []);

  const handleRequestPushNotifications = async () => {
    if ('Notification' in window) {
      const perm = await Notification.requestPermission();
      setHasNotificationPermission(perm === 'granted');
      if (perm === 'granted') {
        addToast('Live push notifications enabled! 🔔', 'success');
        try {
          new Notification('foodpanda Alerts Activated', {
            body: 'You will receive real-time order status updates and kitchen alerts.',
            icon: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=100',
          });
        } catch {
          // ignore
        }
      }
    }
  };

  // Initial Data Fetch
  const loadInitialData = async () => {
    try {
      const [restsData, promosData, ridersData, ordersData] = await Promise.all([
        api.getRestaurants(),
        api.getPromos(),
        api.getRiders(),
        api.getOrders(),
      ]);

      setRestaurants(restsData);
      setPromos(promosData);
      setRiders(ridersData);
      setOrders(ordersData);

      // Set active order if any is pending/in-progress
      const active = ordersData.find(
        (o) => o.status !== 'delivered' && o.status !== 'cancelled'
      );
      if (active) {
        setActiveOrder(active);
      } else if (ordersData.length > 0) {
        setActiveOrder(ordersData[0]);
      }
    } catch (err) {
      console.error('Failed to load initial data', err);
    }
  };

  useEffect(() => {
    loadInitialData();
  }, []);

  // WebSocket Live Real-Time Integration
  useEffect(() => {
    const unsubscribe = connectWebSocket((event: WebSocketEvent) => {
      if (event.type === 'ORDER_CREATED') {
        setOrders((prev) => [event.order, ...prev]);
        addToast(
          `New order placed #${event.order.id} for ৳${event.order.totals.total}! 🛍️`,
          'info'
        );
      } else if (event.type === 'ORDER_STATUS_UPDATED') {
        setOrders((prev) =>
          prev.map((o) => (o.id === event.order.id ? event.order : o))
        );
        setActiveOrder((prev) => (prev?.id === event.order.id ? event.order : prev));

        // Push notification trigger
        addToast(event.notification.body, 'info');

        if ('Notification' in window && Notification.permission === 'granted') {
          try {
            new Notification(event.notification.title, {
              body: event.notification.body,
            });
          } catch {
            // ignore
          }
        }
      } else if (event.type === 'RESTAURANTS_UPDATED' || event.type === 'MENU_UPDATED') {
        api.getRestaurants().then(setRestaurants).catch(console.error);
      } else if (event.type === 'PROMOS_UPDATED') {
        api.getPromos().then(setPromos).catch(console.error);
      } else if (event.type === 'RIDERS_UPDATED') {
        api.getRiders().then(setRiders).catch(console.error);
      }
    });

    return () => unsubscribe();
  }, []);

  // Cart operations
  const handleAddToCart = (item: any, rest: Restaurant) => {
    setCart((prev) => {
      const existing = prev.find((c) => c.itemId === item.id);
      if (existing) {
        return prev.map((c) =>
          c.itemId === item.id ? { ...c, qty: c.qty + 1 } : c
        );
      }
      return [
        ...prev,
        {
          itemId: item.id,
          restId: rest.id,
          restName: rest.name,
          name: item.name,
          price: item.price,
          qty: 1,
          fee: rest.fee,
        },
      ];
    });
    addToast(`Added "${item.name}" to cart 🛒`, 'success');
  };

  const handleUpdateCartQty = (itemId: number, delta: number) => {
    setCart((prev) => {
      return prev
        .map((c) => {
          if (c.itemId === itemId) {
            return { ...c, qty: c.qty + delta };
          }
          return c;
        })
        .filter((c) => c.qty > 0);
    });
  };

  const handleRemoveCartItem = (itemId: number) => {
    setCart((prev) => prev.filter((c) => c.itemId !== itemId));
    addToast('Item removed from cart', 'info');
  };

  const handleToggleFavorite = (id: number, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setFavorites((prev) => {
      const exists = prev.includes(id);
      if (exists) {
        addToast('Removed from favorites', 'info');
        return prev.filter((favId) => favId !== id);
      }
      addToast('Added to favorites! ❤️', 'success');
      return [...prev, id];
    });
  };

  // Auth Handlers
  const handleLogin = async (email: string, pass: string, role: UserRole) => {
    const res = await api.login(email, pass, role);
    setUser(res.user);
    const newMode = res.user.role === 'admin' ? 'admin' : 'customer';
    setAppMode(newMode);
    setCurrentView(newMode === 'admin' ? 'admin' : 'home');
    addToast(`Welcome ${res.user.name}! 🎉`, 'success');
  };

  const handleRegister = async (data: any) => {
    const res = await api.register(data);
    setUser(res.user);
    setAppMode(res.user.role === 'admin' ? 'admin' : 'customer');
    setCurrentView(res.user.role === 'admin' ? 'admin' : 'home');
    addToast('Account created successfully! 🚀', 'success');
  };

  const handleLogout = () => {
    setUser(null);
    setAppMode('customer');
    setCurrentView('home');
    addToast('Logged out safely', 'info');
  };

  const handleToggleAppMode = () => {
    const nextMode = appMode === 'admin' ? 'customer' : 'admin';
    setAppMode(nextMode);
    setCurrentView(nextMode === 'admin' ? 'admin' : 'home');
    addToast(
      nextMode === 'admin' ? 'Switched to Admin Panel 🛡️' : 'Switched to Customer View 🍽️',
      'info'
    );
  };

  // Order Placement with Secure Payment Gateway Simulation
  const handleCheckout = async (checkoutData: any) => {
    setPaymentModalState({
      isOpen: true,
      status: 'processing',
      method: checkoutData.paymentMethod,
      amount: checkoutData.totals.total,
    });

    try {
      // 1. Process payment via backend gateway
      const paymentRes = await api.processPayment({
        paymentMethod: checkoutData.paymentMethod,
        amount: checkoutData.totals.total,
        cardDetails: checkoutData.cardDetails,
      });

      // 2. Delay for realistic banking token verification
      await new Promise((r) => setTimeout(r, 1600));

      setPaymentModalState((prev) => ({ ...prev, status: 'success' }));

      // 3. Create real order on backend
      const createdOrder = await api.createOrder({
        userId: user?.id || 'usr-1',
        customerName: user?.name || 'Customer',
        customerPhone: user?.phone || '017XXXXXXXX',
        items: cart,
        totals: checkoutData.totals,
        address: checkoutData.address,
        notes: checkoutData.notes,
        paymentMethod: checkoutData.paymentMethod,
        transactionId: paymentRes.transactionId,
      });

      // 4. Update local state
      setActiveOrder(createdOrder);
      setCart([]);

      // 5. Transition to tracking
      setTimeout(() => {
        setPaymentModalState((prev) => ({ ...prev, isOpen: false }));
        setCurrentView('tracking');
        addToast('Order confirmed and sent to restaurant! 🛵', 'success');
      }, 1500);
    } catch (err: any) {
      setPaymentModalState((prev) => ({ ...prev, isOpen: false }));
      addToast(err.message || 'Payment processing failed', 'error');
    }
  };

  // Filter restaurants by category
  const filteredRestaurants =
    activeCategory === 'All'
      ? restaurants
      : restaurants.filter((r) => r.cats.includes(activeCategory));

  const selectedRest = restaurants.find((r) => r.id === selectedRestId);

  // If user is not logged in, show foodpanda Auth view
  if (!user) {
    return (
      <>
        <ToastContainer toasts={toasts} onDismiss={removeToast} />
        <AuthModal onLogin={handleLogin} onRegister={handleRegister} />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAFAFC] text-gray-900 flex flex-col font-sans selection:bg-[#E21B70] selection:text-white pb-16 sm:pb-0">
      <ToastContainer toasts={toasts} onDismiss={removeToast} />

      {/* Main Responsive Header */}
      <Header
        user={user}
        appMode={appMode}
        cartCount={cart.reduce((s, c) => s + c.qty, 0)}
        favCount={favorites.length}
        userLocation={userLocation}
        restaurants={restaurants}
        onNavigate={(view) => {
          setCurrentView(view);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onToggleAppMode={handleToggleAppMode}
        onOpenLocationModal={() => setIsLocationModalOpen(true)}
        onSelectRestaurant={(id) => {
          setSelectedRestId(id);
          setCurrentView('restaurant');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* Location Picker Modal */}
      <LocationModal
        isOpen={isLocationModalOpen}
        currentLocation={userLocation}
        onClose={() => setIsLocationModalOpen(false)}
        onSaveLocation={(loc) => {
          setUserLocation(loc);
          addToast(`Delivery location set to: ${loc}`, 'success');
        }}
      />

      {/* Payment Processing & Success Modal */}
      <PaymentModal
        isOpen={paymentModalState.isOpen}
        status={paymentModalState.status}
        paymentMethod={paymentModalState.method}
        amount={paymentModalState.amount}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-4 sm:py-6">
        {/* ==========================================
            VIEW: HOME (CUSTOMER)
        ========================================== */}
        {currentView === 'home' && (
          <div className="space-y-6 animate-in fade-in duration-300">
            {/* foodpanda it Hero */}
            <section className="bg-gradient-to-r from-white via-pink-50/40 to-pink-100/60 rounded-3xl p-6 sm:p-12 border border-pink-100 shadow-sm flex flex-col lg:flex-row items-center justify-between gap-8">
              <div className="max-w-xl space-y-4 text-center lg:text-left">
                <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-gray-900 tracking-tight leading-none">
                  Hungry? <br />
                  <span className="text-[#E21B70]">foodpanda</span> it.
                </h1>
                <p className="text-xs sm:text-base text-gray-600 max-w-md mx-auto lg:mx-0 leading-relaxed">
                  Discover the best restaurants in Dhaka and beyond — hot Kacchi biryani, cheesy pizza, smash burgers, and sweet desserts delivered fast.
                </p>

                {/* Hero Delivery Address Finder Box */}
                <div className="bg-white p-2 rounded-2xl shadow-md border border-pink-100 flex items-center gap-2 max-w-lg mx-auto lg:mx-0">
                  <div className="flex-1 flex items-center gap-2 pl-3">
                    <span className="text-[#E21B70] text-lg">📍</span>
                    <input
                      type="text"
                      value={userLocation}
                      onChange={(e) => setUserLocation(e.target.value)}
                      placeholder="Enter your street or area"
                      className="w-full text-xs sm:text-sm font-semibold text-gray-800 focus:outline-none"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => setIsLocationModalOpen(true)}
                    className="bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-bold px-3 py-2.5 rounded-xl transition flex items-center gap-1 cursor-pointer shrink-0"
                  >
                    <Crosshair className="w-3.5 h-3.5 text-[#E21B70]" />
                    <span className="hidden sm:inline">Locate</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      document.getElementById('restaurants-grid')?.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="bg-[#E21B70] hover:bg-[#c4155f] text-white text-xs sm:text-sm font-black px-5 py-2.5 rounded-xl transition shadow-md shadow-pink-200 cursor-pointer shrink-0"
                  >
                    Find Food
                  </button>
                </div>
              </div>

              {/* Hero Image */}
              <div className="relative w-full max-w-md lg:max-w-lg aspect-4/3 rounded-2xl overflow-hidden shadow-xl border-4 border-white">
                <img
                  src="https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=900&q=80"
                  alt="Delicious food delivery"
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-3 left-3 bg-white/90 backdrop-blur-md px-3.5 py-1.5 rounded-xl text-xs font-black text-gray-900 shadow-md">
                  🚀 25-35 min average delivery
                </div>
              </div>
            </section>

            {/* Voucher Carousel */}
            <PromoSlider
              onApplyCode={(code) => {
                addToast(`Promo voucher "${code}" copied! Apply in your cart 🎟️`, 'success');
              }}
            />

            {/* Categories Chips */}
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <h2 className="text-lg sm:text-xl font-black text-gray-900">
                  Popular Categories
                </h2>
                <span className="text-xs text-gray-400 font-medium">
                  {filteredRestaurants.length} restaurants
                </span>
              </div>
              <CategoryBar
                categories={CATEGORIES}
                activeCategory={activeCategory}
                onSelectCategory={(cat) => setActiveCategory(cat)}
              />
            </div>

            {/* Restaurants Grid */}
            <section id="restaurants-grid" className="space-y-4 pt-2">
              <div className="flex items-center justify-between">
                <h2 className="text-xl sm:text-2xl font-black text-gray-900 tracking-tight">
                  {activeCategory === 'All' ? 'All Restaurants' : `${activeCategory} Restaurants`}
                </h2>
                {activeCategory !== 'All' && (
                  <button
                    type="button"
                    onClick={() => setActiveCategory('All')}
                    className="text-xs font-bold text-[#E21B70] hover:underline cursor-pointer"
                  >
                    Show All
                  </button>
                )}
              </div>

              {filteredRestaurants.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
                  {filteredRestaurants.map((r) => (
                    <RestaurantCard
                      key={r.id}
                      restaurant={r}
                      isFavorite={favorites.includes(r.id)}
                      onSelect={(id) => {
                        setSelectedRestId(id);
                        setCurrentView('restaurant');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      onToggleFavorite={handleToggleFavorite}
                    />
                  ))}
                </div>
              ) : (
                <div className="py-16 text-center text-gray-400">
                  <div className="text-5xl mb-2">🍽️</div>
                  <h3 className="font-bold text-gray-800">No restaurants in this category</h3>
                  <p className="text-xs text-gray-400 mt-1">Try selecting another category or clear filters</p>
                </div>
              )}
            </section>
          </div>
        )}

        {/* ==========================================
            VIEW: RESTAURANT DETAIL
        ========================================== */}
        {currentView === 'restaurant' && selectedRest && (
          <RestaurantDetail
            restaurant={selectedRest}
            cart={cart}
            isFavorite={favorites.includes(selectedRest.id)}
            onBack={() => setCurrentView('home')}
            onAddToCart={handleAddToCart}
            onUpdateCartQty={handleUpdateCartQty}
            onToggleFavorite={handleToggleFavorite}
          />
        )}

        {/* ==========================================
            VIEW: CART & CHECKOUT
        ========================================== */}
        {currentView === 'cart' && (
          <CartView
            cart={cart}
            userAddress={userLocation}
            promoRules={promos}
            onUpdateQty={handleUpdateCartQty}
            onRemoveItem={handleRemoveCartItem}
            onCheckout={handleCheckout}
            onBrowse={() => setCurrentView('home')}
          />
        )}

        {/* ==========================================
            VIEW: LIVE ORDER TRACKING
        ========================================== */}
        {currentView === 'tracking' && (
          <OrderTracking
            order={activeOrder}
            onBrowseMore={() => setCurrentView('home')}
            onRequestPushNotifications={handleRequestPushNotifications}
            hasNotificationPermission={hasNotificationPermission}
          />
        )}

        {/* ==========================================
            VIEW: FAVORITES
        ========================================== */}
        {currentView === 'favorites' && (
          <div className="space-y-5 animate-in fade-in duration-300">
            <h1 className="text-2xl font-black text-gray-900 flex items-center gap-2">
              <Heart className="w-6 h-6 text-[#E21B70] fill-[#E21B70]" />
              <span>Favorite Restaurants ({favorites.length})</span>
            </h1>

            {favorites.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
                {restaurants
                  .filter((r) => favorites.includes(r.id))
                  .map((r) => (
                    <RestaurantCard
                      key={r.id}
                      restaurant={r}
                      isFavorite={true}
                      onSelect={(id) => {
                        setSelectedRestId(id);
                        setCurrentView('restaurant');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      onToggleFavorite={handleToggleFavorite}
                    />
                  ))}
              </div>
            ) : (
              <div className="py-16 text-center max-w-sm mx-auto">
                <div className="w-16 h-16 rounded-full bg-pink-50 text-[#E21B70] flex items-center justify-center mx-auto mb-3">
                  <Heart className="w-8 h-8" />
                </div>
                <h3 className="font-bold text-gray-900 mb-1">No favorites saved yet</h3>
                <p className="text-xs text-gray-500 mb-4">
                  Tap the heart icon on any restaurant to quickly access them here anytime.
                </p>
                <button
                  type="button"
                  onClick={() => setCurrentView('home')}
                  className="bg-[#E21B70] hover:bg-[#c4155f] text-white text-xs font-bold px-5 py-2.5 rounded-xl transition cursor-pointer"
                >
                  Explore Restaurants
                </button>
              </div>
            )}
          </div>
        )}

        {/* ==========================================
            VIEW: PROFILE
        ========================================== */}
        {currentView === 'profile' && (
          <ProfileView
            user={user}
            orders={orders}
            onNavigate={(view) => {
              setCurrentView(view);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onLogout={handleLogout}
          />
        )}

        {/* ==========================================
            VIEW: ADMIN PERSPECTIVE
        ========================================== */}
        {currentView === 'admin' && (
          <AdminPanel
            restaurants={restaurants}
            riders={riders}
            promos={promos}
            orders={orders}
            onAddRestaurant={async (data) => {
              try {
                await api.addRestaurant(data);
                addToast('Restaurant added successfully! 🏪', 'success');
              } catch {
                addToast('Failed to add restaurant', 'error');
              }
            }}
            onDeleteRestaurant={async (id) => {
              if (confirm('Delete this restaurant and its menu items?')) {
                try {
                  await api.deleteRestaurant(id);
                  addToast('Restaurant deleted', 'info');
                } catch {
                  addToast('Failed to delete restaurant', 'error');
                }
              }
            }}
            onAddMenuItem={async (restId, item) => {
              try {
                await api.addMenuItem(restId, item);
                addToast(`Item "${item.name}" added to menu! 🍲`, 'success');
              } catch {
                addToast('Failed to add menu item', 'error');
              }
            }}
            onDeleteMenuItem={async (restId, itemId) => {
              if (confirm('Delete this food item?')) {
                try {
                  await api.deleteMenuItem(restId, itemId);
                  addToast('Item removed from menu', 'info');
                } catch {
                  addToast('Failed to remove item', 'error');
                }
              }
            }}
            onAddPromo={async (promo) => {
              try {
                await api.addPromo(promo);
                addToast(`Voucher code "${promo.code}" created! 🎟️`, 'success');
              } catch {
                addToast('Failed to create promo', 'error');
              }
            }}
            onDeletePromo={async (code) => {
              if (confirm(`Delete promo code "${code}"?`)) {
                try {
                  await api.deletePromo(code);
                  addToast(`Promo "${code}" deleted`, 'info');
                } catch {
                  addToast('Failed to delete promo', 'error');
                }
              }
            }}
            onAddRider={async (rider) => {
              try {
                await api.addRider(rider);
                addToast(`Delivery Hero "${rider.name}" registered! 🛵`, 'success');
              } catch {
                addToast('Failed to add rider', 'error');
              }
            }}
            onUpdateRiderStatus={async (id, status) => {
              try {
                await api.updateRider(id, { status });
                addToast(`Rider status updated to ${status}`, 'success');
              } catch {
                addToast('Failed to update rider status', 'error');
              }
            }}
            onDeleteRider={async (id) => {
              if (confirm('Remove this rider from fleet?')) {
                try {
                  await api.deleteRider(id);
                  addToast('Rider removed from fleet', 'info');
                } catch {
                  addToast('Failed to remove rider', 'error');
                }
              }
            }}
            onUpdateOrderStatus={async (orderId, status) => {
              try {
                await api.updateOrderStatus(orderId, status);
                addToast(`Order #${orderId} marked as ${status.toUpperCase()}! 📡`, 'success');
              } catch {
                addToast('Failed to update order status', 'error');
              }
            }}
            onSwitchToCustomer={() => {
              setAppMode('customer');
              setCurrentView('home');
            }}
          />
        )}
      </main>

      {/* Mobile Bottom Navigation Bar */}
      <nav className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-gray-200 px-2 py-1.5 flex justify-around items-center shadow-lg">
        <button
          type="button"
          onClick={() => setCurrentView('home')}
          className={`flex flex-col items-center gap-0.5 text-[10px] font-bold ${
            currentView === 'home' ? 'text-[#E21B70]' : 'text-gray-500'
          }`}
        >
          <Home className="w-5 h-5" />
          <span>Home</span>
        </button>

        <button
          type="button"
          onClick={() => setCurrentView('favorites')}
          className={`flex flex-col items-center gap-0.5 text-[10px] font-bold ${
            currentView === 'favorites' ? 'text-[#E21B70]' : 'text-gray-500'
          }`}
        >
          <Heart className="w-5 h-5" />
          <span>Saved</span>
        </button>

        <button
          type="button"
          onClick={() => setCurrentView('cart')}
          className={`flex flex-col items-center gap-0.5 text-[10px] font-bold relative ${
            currentView === 'cart' ? 'text-[#E21B70]' : 'text-gray-500'
          }`}
        >
          <ShoppingCart className="w-5 h-5" />
          <span>Cart</span>
          {cart.length > 0 && (
            <span className="absolute -top-1 right-2 bg-[#E21B70] text-white text-[9px] w-4 h-4 rounded-full flex items-center justify-center font-black">
              {cart.reduce((s, c) => s + c.qty, 0)}
            </span>
          )}
        </button>

        <button
          type="button"
          onClick={() => setCurrentView('tracking')}
          className={`flex flex-col items-center gap-0.5 text-[10px] font-bold ${
            currentView === 'tracking' ? 'text-[#E21B70]' : 'text-gray-500'
          }`}
        >
          <Clock className="w-5 h-5" />
          <span>Track</span>
        </button>

        <button
          type="button"
          onClick={() => setCurrentView('profile')}
          className={`flex flex-col items-center gap-0.5 text-[10px] font-bold ${
            currentView === 'profile' ? 'text-[#E21B70]' : 'text-gray-500'
          }`}
        >
          <UserIcon className="w-5 h-5" />
          <span>Profile</span>
        </button>
      </nav>
    </div>
  );
}
